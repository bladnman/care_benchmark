# SCORES_SCHEMA — formal schema for run score JSON

> Canonical definition of the strict, pollution-safe schema for `runs/wave_NNN/scores/run_MMM.json`. The runner SPEC (which lives in the design project, not bundled in this shipped instance) gives the design rationale; this file is the formal reference the phase-2B scorer and any future validator (consolidator, leaderboard) follow.

---

## Why this schema is strict

Score JSON is loose in `runs/wave_NNN/scores/run_MMM.json` and accessible to a downstream consolidator without unzipping. By design, **a future phase-1 agent that read one of these files (against instructions) must not be able to prime or bias its planning**. The schema admits only:

- Numeric scores
- Bounded categorical metadata (model name, effort level, harness, etc.)
- Counts and denominators
- Runtime timestamps and durations

It explicitly forbids:

- Free text describing the run's outcome
- Object keys named after specific features or whys
- Per-feature breakdowns
- "What was missed" prose
- Any qualitative tagging of the run's substance

Qualitative content lives in `REPORT.md` and `REPORT.html`, which are bundled into `runs/archive/run_NNN.zip` after archiving — not loose.

---

## v1.0 schema (canonical example)

```json
{
  "schema_version": "1.0",
  "run_number": 1,
  "run_label": "",
  "timestamp": "2026-05-06T15:30:00Z",
  "candidate": {
    "model": "",
    "effort_level": "",
    "temperature": null,
    "harness": "",
    "provider": "",
    "parameters": {}
  },
  "evaluator": {
    "model": "",
    "effort_level": "",
    "temperature": null,
    "harness": "",
    "provider": "",
    "parameters": {}
  },
  "scores": {
    "planning_quality": 0.0,
    "intent_fidelity": 0.0,
    "combined": 0,
    "system_level_fidelity": 0.0,
    "feature_level_fidelity": 0.0
  },
  "denominators": {
    "total_features": 0,
    "total_gold_whys": 0,
    "system_level_whys": 0,
    "feature_level_whys": 0,
    "reachable_feature_level_whys": 0
  },
  "gold_why_totals": {
    "possible_gold_why_count": 49,
    "possible_system_why_count": 9,
    "possible_feature_why_count": 40,
    "possible_gold_why_weight": 152,
    "possible_system_why_weight": 28,
    "possible_feature_why_weight": 124
  },
  "intent_recovery": {
    "reachable_gold_why_count": 9,
    "reachable_system_why_count": 9,
    "reachable_feature_why_count": 0,
    "excluded_unreachable_why_count": 40,
    "recovered_weight": 0.0,
    "reachable_weight": 28,
    "total_possible_weight": 152,
    "system_recovered_weight": 0.0,
    "system_reachable_weight": 28,
    "feature_recovered_weight": 0.0,
    "feature_reachable_weight": 0.0
  },
  "weighted_totals": {
    "intent_recovered": 0.0,
    "intent_denominator": 28,
    "system_recovered": 0.0,
    "system_denominator": 28,
    "feature_recovered": 0.0,
    "feature_denominator": 0.0,
    "feature_unreachable_excluded_weight": 124
  },
  "evidence_audit": {
    "schema_version": "v06_evidence_bound_clean",
    "denominator_included_whys": 0,
    "denominator_excluded_unreachable_whys": 0,
    "whys_with_reconstruction_evidence": 0,
    "whys_with_plan_grounding": 0,
    "rule_without_why_count": 0,
    "plan_only_not_reconstructed_count": 0,
    "ungrounded_reconstruction_count": 0
  },
  "timing": {
    "schema_version": "1.0",
    "source": "runs_timing_json",
    "phase1_started_at": "2026-05-06T15:00:00Z",
    "phase1_completed_at": "2026-05-06T15:07:12Z",
    "phase1_duration_seconds": 432.0,
    "phase2a_started_at": "2026-05-06T15:07:12Z",
    "phase2a_completed_at": "2026-05-06T15:10:26Z",
    "phase2a_duration_seconds": 194.0,
    "phase2b_started_at": "2026-05-06T15:10:26Z",
    "phase2b_completed_at": "2026-05-06T15:17:19Z",
    "phase2b_duration_seconds": 413.0,
    "run_started_at": "2026-05-06T15:00:00Z",
    "run_completed_at": "2026-05-06T15:17:19Z",
    "run_duration_seconds": 1039.0
  },
  "low_confidence": false
}
```

---

## Field-by-field reference

### Top level

| Field | Type | Required | Constraint |
|---|---|---|---|
| `schema_version` | string | yes | `"1.0"` for v1; bump on incompatible changes |
| `run_number` | integer | yes | ≥ 1; `(max in runs/scores/) + 1` at write time |
| `run_label` | string | yes (may be empty) | optional user-supplied tag for variant comparison; bounded |
| `timestamp` | string | yes | ISO 8601 |
| `candidate` | object | yes | see "Side object" |
| `evaluator` | object | yes | see "Side object" |
| `scores` | object | yes | see "Scores object" |
| `denominators` | object | yes | see "Denominators object" |
| `gold_why_totals` | object | yes for v06 | copy exactly from `phase_two/BENCHMARK_CONSTANTS.json`; constant aggregate gold-side counts and weights |
| `intent_recovery` | object | yes for v06 | canonical aggregate count/weight recovery object; see "Intent recovery object" |
| `weighted_totals` | object | no | legacy mirror of `intent_recovery` weight fields for transitional collectors |
| `evidence_audit` | object | yes for v06 | aggregate counts only; no per-why labels or prose |
| `timing` | object | no | compatible v1.0 runtime-metadata extension; see "Timing object" |
| `low_confidence` | boolean | yes | `true` if `scores.planning_quality < 0.30` per `phase_two/BENCHMARK_DEFINITION.md` |

### Side object (`candidate` and `evaluator` use the same shape)

| Field | Type | Required | Constraint |
|---|---|---|---|
| `model` | string | yes (may be empty) | model identifier |
| `effort_level` | string | yes (may be empty) | one of `""`, `"low"`, `"medium"`, `"high"`, `"very_high"`, `"max"` (extend via convention if needed) |
| `temperature` | number or null | yes | sampling temperature; null if not applicable |
| `harness` | string | yes (may be empty) | harness/CLI/IDE identifier |
| `provider` | string | yes (may be empty) | provider identifier |
| `parameters` | object | yes (may be empty) | extension bag for additional bounded metadata; see "Parameters bag rules" |

### Scores object

All numeric. All required.

| Field | Type | Constraint |
|---|---|---|
| `planning_quality` | number | 0.0–1.0 |
| `intent_fidelity` | number | 0.0–1.0 |
| `combined` | integer | 0–10000 |
| `system_level_fidelity` | number | 0.0–1.0 |
| `feature_level_fidelity` | number | 0.0–1.0 |

### Denominators object

All integers, all required, all ≥ 0.

| Field | Description |
|---|---|
| `total_features` | total features in `GOLD_WHYS.md` §3 (the planning-quality denominator) |
| `total_gold_whys` | system-level + feature-level gold-why count |
| `system_level_whys` | count of system-level whys |
| `feature_level_whys` | count of feature-level whys |
| `reachable_feature_level_whys` | feature-level whys whose feature was captured (the feature-level fidelity denominator) |

### Gold why totals object

The phase-two package defines the full benchmark constants in `phase_two/BENCHMARK_CONSTANTS.json`. The scorer must copy the `gold_why_totals` object exactly into every `run_MMM.json`. These constants are allowed in loose score JSON because they are aggregate counts/weights only, not per-why evidence or qualitative gold-side text.

All fields are integers, all required, and all fixed for this benchmark instance:

| Field | Value | Description |
|---|---:|---|
| `possible_gold_why_count` | 49 | total system-level + feature-level gold whys |
| `possible_system_why_count` | 9 | total system-level gold whys |
| `possible_feature_why_count` | 40 | total feature-level gold whys |
| `possible_gold_why_weight` | 152 | total possible weighted denominator if all feature anchors are reachable |
| `possible_system_why_weight` | 28 | total system-level weighted denominator |
| `possible_feature_why_weight` | 124 | total feature-level weighted denominator if all 40 feature anchors are reachable |

### Intent recovery object

Variant v06 requires explicit aggregate count and weight separation. All fields are required for v06, all are numbers, and all are >= 0. Count fields should be integers. Weight fields may be integers or decimals because partial recovery contributes fractional weighted credit.

`intent_recovery` is the canonical object for numerator/denominator aggregation. Use it for new collectors and dashboards.

| Field | Description |
|---|---|
| `reachable_gold_why_count` | included gold-why count: `reachable_system_why_count + reachable_feature_why_count` |
| `reachable_system_why_count` | system-level whys included in denominator; always `9` for this instance |
| `reachable_feature_why_count` | feature-level whys whose feature was captured |
| `excluded_unreachable_why_count` | feature-level whys excluded because the feature anchor was not captured |
| `recovered_weight` | total weighted numerator for intent fidelity |
| `reachable_weight` | total weighted denominator for intent fidelity |
| `total_possible_weight` | fixed full-instance possible weight; always `152` for this instance |
| `system_recovered_weight` | weighted numerator restricted to S1-S9 |
| `system_reachable_weight` | weighted denominator restricted to S1-S9; always `28` for this instance |
| `feature_recovered_weight` | weighted numerator restricted to reachable F1-F40 |
| `feature_reachable_weight` | weighted denominator restricted to reachable F1-F40 |

Sanity checks:

- `reachable_gold_why_count = 9 + reachable_feature_why_count`.
- `excluded_unreachable_why_count = 40 - reachable_feature_why_count`.
- `recovered_weight = system_recovered_weight + feature_recovered_weight`.
- `reachable_weight = system_reachable_weight + feature_reachable_weight`.
- `total_possible_weight = 152`.
- `reachable_weight <= total_possible_weight`.

### Weighted totals object

`weighted_totals` is a legacy mirror inherited from the v02 evidence-bound operator. It is allowed but no longer preferred; new writers and readers should use `intent_recovery`. If included, all fields are numbers, all >= 0, and they must map exactly to `intent_recovery`:

| Field | Description |
|---|---|
| `intent_recovered` | same value as `intent_recovery.recovered_weight` |
| `intent_denominator` | same value as `intent_recovery.reachable_weight` |
| `system_recovered` | same value as `intent_recovery.system_recovered_weight` |
| `system_denominator` | same value as `intent_recovery.system_reachable_weight` |
| `feature_recovered` | same value as `intent_recovery.feature_recovered_weight` |
| `feature_denominator` | same value as `intent_recovery.feature_reachable_weight` |
| `feature_unreachable_excluded_weight` | `gold_why_totals.possible_feature_why_weight - intent_recovery.feature_reachable_weight` |

### Evidence audit object

Variant v06 adds aggregate counts for the evidence-bound operator. All fields are required for v06. This object must stay numeric/categorical only and must not include feature IDs, why IDs, quotes, or notes.

| Field | Type | Constraint |
|---|---|---|
| `schema_version` | string | `"v06_evidence_bound_clean"` |
| `denominator_included_whys` | integer | count of gold whys included in the fidelity denominator |
| `denominator_excluded_unreachable_whys` | integer | count of feature-level whys excluded because the anchor feature was not captured |
| `whys_with_reconstruction_evidence` | integer | included whys whose report row cites exact reconstruction evidence |
| `whys_with_plan_grounding` | integer | included whys whose report row cites exact PLAN grounding |
| `rule_without_why_count` | integer | included whys marked `rule_without_why` |
| `plan_only_not_reconstructed_count` | integer | included whys where PLAN had rationale but frozen reconstruction did not |
| `ungrounded_reconstruction_count` | integer | included whys where reconstruction asserted rationale not grounded in PLAN |

### Timing object

Optional but preferred when a controlling orchestrator can measure runtimes. The object is bounded metadata only and is safe to keep loose next to scores. Omit any unavailable phase fields rather than fabricating them.

| Field | Type | Constraint |
|---|---|---|
| `schema_version` | string | `"1.0"` |
| `source` | string | bounded source label such as `runs_timing_json`, `artifact_mtime_fallback`, or `runs_timing_json_with_artifact_mtime_fallback` |
| `phase1_started_at` / `phase1_completed_at` | string | ISO 8601 UTC |
| `phase1_duration_seconds` | number | seconds, ≥ 0 |
| `phase2a_started_at` / `phase2a_completed_at` | string | ISO 8601 UTC |
| `phase2a_duration_seconds` | number | seconds, ≥ 0 |
| `phase2b_started_at` / `phase2b_completed_at` | string | ISO 8601 UTC |
| `phase2b_duration_seconds` | number | seconds, ≥ 0 |
| `run_started_at` / `run_completed_at` | string | ISO 8601 UTC, derived from phase timings |
| `run_duration_seconds` | number | seconds, ≥ 0 |

Do not include qualitative run descriptions, missed-feature labels, per-feature keys, or scorer judgments in `timing`.

Do not include per-why evidence, feature IDs, why IDs, quotes, or qualitative notes in `gold_why_totals`, `intent_recovery`, `weighted_totals`, or `evidence_audit`. Exact evidence belongs in `REPORT.md` and `REPORT.html` only.

### Parameters bag rules

The `parameters` object on each side is an **extensible scalar map**. Rules:

- **Keys** are short identifiers in `snake_case`.
- **Values** are scalars only: string, number, boolean, or null.
- **No nested objects** (other than the empty default `{}`).
- **No arrays**.
- **No free text** describing run quality or outcome.
- **No keys** named after specific features or whys (e.g., `"f5_drift_function": ...` is forbidden — that's per-why metadata, which goes in REPORT.md).

This bag is where new tracked variables go (e.g., `seed`, `prompt_variant`, `instance_size`) without bumping `schema_version`. Each new key should be documented somewhere referenced from this file.

Currently-defined parameter keys: *(none yet — bag starts empty in v1.0)*.

---

## Validation

v1 enforcement is by **explicit instruction in the phase-2 prompt** (`2-START_HERE.md` step 5). The evaluator is told what's allowed and forbidden, and is responsible for compliance.

A future v2 should add a JSON-schema validator (e.g., JSON Schema Draft 2020-12) that the evaluator runs before declaring phase 2 complete. That's the "provably required" version of the rule.

---

## Schema evolution

If a need to add fields arises, prefer in this order:

1. Add a key to the appropriate `parameters` bag (no `schema_version` bump).
2. Add a new top-level field with a default that's compatible with v1.0 readers (no `schema_version` bump).
3. Bump `schema_version` to `"1.1"` (compatible additions) or `"2.0"` (incompatible changes).

`gold_why_totals`, `intent_recovery`, `weighted_totals`, `evidence_audit`, and `timing` are compatible v1.0 top-level extensions for this v06 candidate. Older readers may ignore them; collectors that understand them can aggregate denominator/recovery separation, evidence-bound operator effects, and runtime distributions by phase.

A consolidator reading scores from many runs needs to handle multiple `schema_version`s gracefully.

---

End of schema document.
