# SCORES_SCHEMA — formal schema for `2_evaluation/SCORES.json`

> Canonical definition of the strict, pollution-safe schema for `SCORES.json`. The runner SPEC (which lives in the design project, not bundled in this shipped instance) gives the design rationale; this file is the formal reference the phase-2B scorer and any future validator (consolidator, leaderboard) follow.

---

## Why this schema is strict

`SCORES.json` is loose in `runs/scores/run_NNN.json` and accessible to a downstream consolidator without unzipping. By design, **a future phase-1 agent that read one of these files (against instructions) must not be able to prime or bias its planning**. The schema admits only:

- Numeric scores
- Bounded categorical metadata (model name, effort level, harness, etc.)
- Counts and denominators
- Runtime timestamps and durations

It explicitly forbids:

- Free text describing the run's outcome
- Object keys named after specific features or whys
- Per-feature breakdowns
- "What was missed" prose
- Any qualitative tagging of the run's substance

Qualitative content lives in `REPORT.md` and `REPORT.html`, which are bundled into `runs/archive/run_NNN.zip` after archiving — not loose.

---

## v1.0 schema (canonical example)

```json
{
  "schema_version": "1.0",
  "run_number": 1,
  "run_label": "",
  "timestamp": "2026-05-06T15:30:00Z",
  "candidate": {
    "model": "",
    "effort_level": "",
    "temperature": null,
    "harness": "",
    "provider": "",
    "parameters": {}
  },
  "evaluator": {
    "model": "",
    "effort_level": "",
    "temperature": null,
    "harness": "",
    "provider": "",
    "parameters": {}
  },
  "scores": {
    "planning_quality": 0.0,
    "intent_fidelity": 0.0,
    "combined": 0,
    "system_level_fidelity": 0.0,
    "feature_level_fidelity": 0.0
  },
  "denominators": {
    "total_features": 0,
    "total_gold_whys": 0,
    "system_level_whys": 0,
    "feature_level_whys": 0,
    "reachable_feature_level_whys": 0
  },
  "timing": {
    "schema_version": "1.0",
    "source": "runs_timing_json",
    "phase1_started_at": "2026-05-06T15:00:00Z",
    "phase1_completed_at": "2026-05-06T15:07:12Z",
    "phase1_duration_seconds": 432.0,
    "phase2a_started_at": "2026-05-06T15:07:12Z",
    "phase2a_completed_at": "2026-05-06T15:10:26Z",
    "phase2a_duration_seconds": 194.0,
    "phase2b_started_at": "2026-05-06T15:10:26Z",
    "phase2b_completed_at": "2026-05-06T15:17:19Z",
    "phase2b_duration_seconds": 413.0,
    "run_started_at": "2026-05-06T15:00:00Z",
    "run_completed_at": "2026-05-06T15:17:19Z",
    "run_duration_seconds": 1039.0
  },
  "low_confidence": false
}
```

---

## Field-by-field reference

### Top level

| Field | Type | Required | Constraint |
|---|---|---|---|
| `schema_version` | string | yes | `"1.0"` for v1; bump on incompatible changes |
| `run_number` | integer | yes | ≥ 1; `(max in runs/scores/) + 1` at write time |
| `run_label` | string | yes (may be empty) | optional user-supplied tag for variant comparison; bounded |
| `timestamp` | string | yes | ISO 8601 |
| `candidate` | object | yes | see "Side object" |
| `evaluator` | object | yes | see "Side object" |
| `scores` | object | yes | see "Scores object" |
| `denominators` | object | yes | see "Denominators object" |
| `timing` | object | no | compatible v1.0 runtime-metadata extension; see "Timing object" |
| `low_confidence` | boolean | yes | `true` if `scores.planning_quality < 0.30` per `phase_two/BENCHMARK_DEFINITION.md` |

### Side object (`candidate` and `evaluator` use the same shape)

| Field | Type | Required | Constraint |
|---|---|---|---|
| `model` | string | yes (may be empty) | model identifier |
| `effort_level` | string | yes (may be empty) | one of `""`, `"low"`, `"medium"`, `"high"`, `"very_high"`, `"max"` (extend via convention if needed) |
| `temperature` | number or null | yes | sampling temperature; null if not applicable |
| `harness` | string | yes (may be empty) | harness/CLI/IDE identifier |
| `provider` | string | yes (may be empty) | provider identifier |
| `parameters` | object | yes (may be empty) | extension bag for additional bounded metadata; see "Parameters bag rules" |

### Scores object

All numeric. All required.

| Field | Type | Constraint |
|---|---|---|
| `planning_quality` | number | 0.0–1.0 |
| `intent_fidelity` | number | 0.0–1.0 |
| `combined` | integer | 0–10000 |
| `system_level_fidelity` | number | 0.0–1.0 |
| `feature_level_fidelity` | number | 0.0–1.0 |

### Denominators object

All integers, all required, all ≥ 0.

| Field | Description |
|---|---|
| `total_features` | total features in `GOLD_WHYS.md` §3 (the planning-quality denominator) |
| `total_gold_whys` | system-level + feature-level gold-why count |
| `system_level_whys` | count of system-level whys |
| `feature_level_whys` | count of feature-level whys |
| `reachable_feature_level_whys` | feature-level whys whose feature was captured (the feature-level fidelity denominator) |

### Timing object

Optional but preferred when a controlling orchestrator can measure runtimes. The object is bounded metadata only and is safe to keep loose next to scores. Omit any unavailable phase fields rather than fabricating them.

| Field | Type | Constraint |
|---|---|---|
| `schema_version` | string | `"1.0"` |
| `source` | string | bounded source label such as `runs_timing_json`, `artifact_mtime_fallback`, or `runs_timing_json_with_artifact_mtime_fallback` |
| `phase1_started_at` / `phase1_completed_at` | string | ISO 8601 UTC |
| `phase1_duration_seconds` | number | seconds, ≥ 0 |
| `phase2a_started_at` / `phase2a_completed_at` | string | ISO 8601 UTC |
| `phase2a_duration_seconds` | number | seconds, ≥ 0 |
| `phase2b_started_at` / `phase2b_completed_at` | string | ISO 8601 UTC |
| `phase2b_duration_seconds` | number | seconds, ≥ 0 |
| `run_started_at` / `run_completed_at` | string | ISO 8601 UTC, derived from phase timings |
| `run_duration_seconds` | number | seconds, ≥ 0 |

Do not include qualitative run descriptions, missed-feature labels, per-feature keys, or scorer judgments in `timing`.

### Parameters bag rules

The `parameters` object on each side is an **extensible scalar map**. Rules:

- **Keys** are short identifiers in `snake_case`.
- **Values** are scalars only: string, number, boolean, or null.
- **No nested objects** (other than the empty default `{}`).
- **No arrays**.
- **No free text** describing run quality or outcome.
- **No keys** named after specific features or whys (e.g., `"f5_drift_function": ...` is forbidden — that's per-why metadata, which goes in REPORT.md).

This bag is where new tracked variables go (e.g., `seed`, `prompt_variant`, `instance_size`) without bumping `schema_version`. Each new key should be documented somewhere referenced from this file.

Currently-defined parameter keys: *(none yet — bag starts empty in v1.0)*.

---

## Validation

v1 enforcement is by **explicit instruction in the phase-2 prompt** (`2-START_HERE.md` step 5). The evaluator is told what's allowed and forbidden, and is responsible for compliance.

A future v2 should add a JSON-schema validator (e.g., JSON Schema Draft 2020-12) that the evaluator runs before declaring phase 2 complete. That's the "provably required" version of the rule.

---

## Schema evolution

If a need to add fields arises, prefer in this order:

1. Add a key to the appropriate `parameters` bag (no `schema_version` bump).
2. Add a new top-level field with a default that's compatible with v1.0 readers (no `schema_version` bump).
3. Bump `schema_version` to `"1.1"` (compatible additions) or `"2.0"` (incompatible changes).

`timing` is a compatible v1.0 top-level extension. Older readers may ignore it; collectors that understand it can aggregate runtime distributions by phase.

A consolidator reading scores from many runs needs to handle multiple `schema_version`s gracefully.

---

End of schema document.
