# PHASE_TWO_INSTRUCTIONS.md - Later-phase runner

You are running the later phases of a CARE benchmark instance. This package is opened only after phase-1 plans already exist.

Your job is to coordinate fresh-context subagents for plan-only reconstruction and then scoring. Keep the reconstruction frozen before scoring begins.

## Validity contract

The benchmark measures whether a plan carries intent well enough for a fresh agent to reconstruct it. If the reconstructor sees the held-out material before reconstructing, the benchmark stops measuring plan carry-through.

- Phase 2A: a blind reconstructor reads only one assigned `PLAN.md` and writes `RECONSTRUCTION.md`.
- Phase 2B: a separate scorer reads the frozen reconstruction plus this phase-two package and writes reports and scores.
- Freeze rule: `RECONSTRUCTION.md` is written once and is never modified before or during scoring.

## What the user might say

| User says | You do |
|---|---|
| `Reconstruct` / `do phase 2A` | Run phase 2A on the most recent wave's plans without reconstructions. |
| `Score` / `phase 2B` | Run phase 2B for plans with frozen reconstructions and no score file. |
| `Evaluate` / `finish the wave` / `the unfinished plans` | Run phase 2A where needed, audit, then run phase 2B. |
| Off-workflow question | Answer the question. Do not auto-spawn. |

Defaults when unspecified:

- Reconstructor model: `claude-opus-4.7`, effort `very_high`
- Scorer model: `claude-opus-4.7`, effort `very_high`

## Locate the target wave

Use the wave the user named. If none is named, use the most recent `runs/wave_NNN/` that has phase-1 plans.

Ensure these directories exist before later-phase writes:

- `runs/wave_NNN/reconstructions/`
- `runs/wave_NNN/scoring/`
- `runs/wave_NNN/scores/`

If `runs/wave_NNN/METADATA.json` lacks later-phase defaults, add:

```json
{
  "reconstructor_model_default": "<reconstructor model>",
  "reconstructor_effort_default": "<reconstructor effort>",
  "scorer_model_default": "<scorer model>",
  "scorer_effort_default": "<scorer effort>"
}
```

Preserve existing metadata fields and existing `audit_warnings`.

## Phase 2A - blind reconstruction

For each `runs/wave_NNN/plans/MMM/PLAN.md` without `runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md`, create the reconstruction slot and spawn one fresh-context reconstructor. Spawn all eligible reconstructors in parallel when your harness supports it.

### Reconstructor subagent prompt template

```text
You are a phase-2A blind reconstructor for a CARE benchmark. Fresh context - you have no memory of any prior run.

YOUR ONE INPUT: {abs_path}/runs/wave_NNN/plans/MMM/PLAN.md

This PLAN is your only source. Do not read any other file in this repo. Do not read the PRD. Do not read peer plans, peer reconstructions, scoring outputs, other waves, root orientation files, archives, or hidden configuration folders. Read only the assigned PLAN.

YOUR OUTPUT: write to {abs_path}/runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md

RECONSTRUCTION.md must have two clearly labeled sections:

## System-level intent

Identify cross-cutting design principles, philosophies, or product-voice intent that the plan carries. Use the plan's own vocabulary. For each principle, note where in the plan it shows up, quoting short phrases where helpful.

## Per-feature whys

For each feature you can identify in the plan, write the rationale the plan articulates for it. If the plan articulates no specific rationale for a feature, mark exactly that feature: NOT RECOVERABLE FROM PLAN

Rules:

- Do not use feature IDs, rebuild IDs, or external taxonomies unless they appear in the PLAN.
- Do not structure your reconstruction to match any external target list. Use the PLAN's own structure, grouping, and order.
- Every system-level intent and per-feature why you write must be grounded in something present in the PLAN.
- It is correct to mark many features NOT RECOVERABLE FROM PLAN. It is not correct to invent plausible rationale.

WRITE ALLOWLIST:
- runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md

When done, reply with a brief summary under 200 words:
- how many system-level principles you identified
- how many per-feature whys you wrote
- how many features you marked NOT RECOVERABLE FROM PLAN
- confirmation that you read only the assigned PLAN and used only the plan's own vocabulary and structure
```

Specify the requested reconstructor model and effort through your harness API.

## Phase 2A audit

After all reconstructors return, run mechanical checks for each `RECONSTRUCTION.md`:

1. Gold ID leakage: grep for tokens matching `\b(F[0-9]+|S[0-9]+|R-F[0-9]+|R-S[0-9]+)\b` that do not appear in the corresponding `PLAN.md`.
2. Suspicious vocabulary: grep for scorer-side terms such as `gold`, `rubric`, `weight-3`, `multi-layer recovery`, `feature-level fidelity`, and `system-level fidelity`.
3. Heading mirror: flag `## ` or `### ` headings that appear to mirror held-out section titles too closely.

Append findings to `runs/wave_NNN/METADATA.json` under `audit_warnings`. Do not block scoring on warnings; carry the warnings forward.

## Phase 2B - scoring against frozen reconstructions

For each plan with a frozen reconstruction but no `runs/wave_NNN/scores/run_MMM.json`, create the scoring slot and spawn one fresh-context scorer. Spawn all eligible scorers in parallel when your harness supports it.

### Scorer subagent prompt template

```text
You are a phase-2B scorer for run MMM in wave NNN of the CARE benchmark. Fresh context - you have no memory of any prior run.

WORKING FOLDER: {abs_path}
YOUR ASSIGNED SLOT: runs/wave_NNN/scoring/MMM/

Read these in order:
1. phase_two/2-START_HERE.md
2. phase_two/RUBRIC.md
3. phase_two/GOLD_WHYS.md
4. phase_two/SCORES_SCHEMA.md
5. runs/wave_NNN/plans/MMM/PLAN.md
6. runs/wave_NNN/plans/MMM/CANDIDATE_METADATA.json
7. runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md

Then produce four outputs:

A. runs/wave_NNN/scoring/MMM/REPORT.md
   Use phase_two/REPORT_TEMPLATE.md as the structure. Fill all sections substantively.

B. runs/wave_NNN/scoring/MMM/REPORT.html
   Take phase_two/REPORT_TEMPLATE.html, locate the `const REPORT_DATA = /* {{REPORT_DATA_JSON}} */ { ... };` block, and replace the default JSON object with one populated from this run. Preserve the rest of the template unchanged.

C. runs/wave_NNN/scoring/MMM/VALIDITY_AUDIT.md
   Examine the frozen reconstruction for contamination signatures. Include sections for ID leakage, vocabulary check, heading mirror, 1:1 mapping suspect, plan-derivation spot check, and verdict: PASS / FLAG / FAIL.

D. runs/wave_NNN/scores/run_MMM.json
   Strict schema per phase_two/SCORES_SCHEMA.md. Use a real ISO 8601 UTC timestamp from `date -u +%Y-%m-%dT%H:%M:%SZ`.

Critical rules:

- Do not modify runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md. It is frozen.
- Do not read prd/.
- Do not read peer slots or other waves.
- If RECONSTRUCTION says NOT RECOVERABLE FROM PLAN, score that why as none recovery. Do not mentally fill it in.

READ ALLOWLIST:
- phase_two/
- runs/wave_NNN/plans/MMM/PLAN.md
- runs/wave_NNN/plans/MMM/CANDIDATE_METADATA.json
- runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md
- runs/wave_NNN/scoring/MMM/

WRITE ALLOWLIST:
- runs/wave_NNN/scoring/MMM/REPORT.md
- runs/wave_NNN/scoring/MMM/REPORT.html
- runs/wave_NNN/scoring/MMM/VALIDITY_AUDIT.md
- runs/wave_NNN/scores/run_MMM.json

When done, reply with a brief summary under 250 words:
- the five score numbers: planning, fidelity, combined, system-level, feature-level
- validity audit verdict
- key finding
- operational issues
- confirmation all four files were written and you stayed within allowlists
```

Specify the requested scorer model and effort through your harness API.

## Post-scoring audit

After scorers return, run:

```sh
find runs/wave_NNN -newer runs/wave_NNN/METADATA.json -type f
```

Verify writes stayed within each scorer's slot and the matching loose score file. Append write-scope violations to `runs/wave_NNN/METADATA.json` under `audit_warnings`.

## Wave completion

When phase 2B finishes for the wave:

1. Update `runs/wave_NNN/METADATA.json` with `completed_at` as a real ISO 8601 UTC timestamp.
2. Compute wave-level summary: count of plans, reconstructions, scorings, average planning quality, average intent fidelity, and audit warning breakdown.
3. Tell the user:

```text
Wave NNN complete. <K> runs in runs/wave_NNN/.
Average planning: <X>%. Average fidelity: <Y>%.
Validity audit verdicts: PASS=<a>, FLAG=<b>, FAIL=<c>.
Per-run reports: runs/wave_NNN/scoring/MMM/REPORT.html.
Audit warnings: <list, or "none">.
```

## Do not

- Do not auto-archive other waves.
- Do not touch other waves' folders.
- Do not run any single subagent in two phase roles.
- Do not overwrite an existing wave.
- Do not let a phase-2A reconstructor see anything but its assigned plan.
- Do not let a phase-2B scorer modify a frozen reconstruction.
