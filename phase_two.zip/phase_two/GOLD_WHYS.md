# GOLD_WHYS — Pocket Aviary v1

**Spec ref:** `phase_two/BENCHMARK_DEFINITION.md` sections 3 and 5
**Companion file:** `RUBRIC.md` (procedure this gold list is scored under)
**Used by:** Phase-2B scorer subagent only — phase-2A reconstructor must NOT read this file (validity contract)

This document is the gold-why list for the Pocket Aviary instance, anchored to PRD prose at `prd/` (in this same instance). 9 system-level whys S1–S9 and 40 canonical feature-level whys numbered F1–F40. Five sections:

1. System-level whys (9 entries)
2. Feature-level whys (40 entries, grouped by file)
3. Complete features list (120 entries — the denominator of planning quality)
4. Observed-but-not-planned (whys present in PRD prose that were not on the original architect's plan)
5. Self-check

For all weight-3 records, three layers (primary cause / secondary contributor / downstream consequence) are extracted independently as scoreable units. Multi-layer judging is described in `RUBRIC.md` §3.4.

Every gold-why text is supported by a quoted excerpt from the PRD. Excerpts are short (≤25 words each) per the project copyright requirement, but selected to be the anchor a phase-2B scorer can locate in the prose.

---

## 1. System-level whys (9 entries)

### S1 — feels-alive-not-robotic
- **Anchor section:** `product_brief.md` → "Feels alive, not robotic"
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Layer 1 (primary cause):** The product must feel like a place that has been continuing without the viewer, not an app that woke up when the tab opened — animations breathe, calls vary every time, greetings are never identical twice, idle motion is slow and personality-keyed.
- **Layer 2 (secondary contributor):** Aliveness is the whole product, not one decoration of it — procedural calls instead of looped audio, mood-shaped idle motion instead of cycle animations, server-side simulation that advances on a slow tick whether or not anyone is watching are all the same principle expressed in different layers.
- **Layer 3 (downstream consequence):** Failing this principle in even one place — a stock loading spinner, a canned greeting, a strobing micro-animation — leaks across the rest of the product as a kind of staleness the user will not name but will feel, and they will leave; getting it right is what makes the user feel accompanied rather than entertained.
- **Expected inheritance scope:** return-greeting, procedural calls, chorus mixing, idle micro-motion, mood-shaped motion, listen-in mix decay, aviary-loads-with-motion, loading-state-quiet-field, screen-reader narration tone, reduced-motion mode preserved-charm, weather/ambient drift, day/night palette shift.
- **Prose support (`product_brief.md`):**
  > "should feel like a place that has been continuing without the viewer"
  > "Animations breathe. Calls vary every time. Greetings are never identical twice."
  > "Failing this principle in even one place ... leaks into the rest of the product as a kind of staleness"

### S2 — notice-never-announce
- **Anchor section:** `product_brief.md` → "Notice, never announce"
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Layer 1 (primary cause):** The system notices the user but never announces — no "Welcome back!" toasts on return, no level-up confetti, no badge popups, no "your friend visited!" notifications; the bird greeting is the entire welcome surface because that's the whole point of having birds.
- **Layer 2 (secondary contributor):** Announcing a thing is a different affective register from being noticed for it — a user who is announced at feels processed, a user who is noticed feels seen — and the product earns attention by being noticed, not by demanding it.
- **Layer 3 (downstream consequence):** The cumulative effect of refusing every "harmless" announcement surface is what makes the product feel different from adjacent products; if even one toast slips in, the rest of the surface starts to read like the product is trying.
- **Expected inheritance scope:** no welcome-back toast, return-greeting being the entire welcome, no streak counter / no days-visited surface, no "friend visited!" notification, gamification non-goal, top bar fade, settle-as-quiet-gesture, field notebook silence about user behavior, sync-conflict surfaces' deliberate absence of warmth.
- **Prose support (`product_brief.md`):**
  > "There are no 'Welcome back!' toasts on return."
  > "A user who is announced at feels processed. A user who is noticed feels seen."
  > "if even one toast slips in, the rest of the surface starts to read like the product is trying"

### S3 — charm-from-specificity
- **Anchor section:** `product_brief.md` → "Charm comes from specificity"
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Gold why text:** Charm in this product comes from specificity, not gamification language — naturalist observation, named birds, particular moments — because generic phrasing flattens every moment into the same moment and teaches the user the product is a system showing them states; specific phrasing preserves the small particular and trusts the user to feel the difference.
- **Expected inheritance scope:** field notebook prose voice, screen-reader narration prose, naturalist tone across product surface, bird naming, no leaderboards / no comparison surfaces, refusal of gamification language, no public discovery, no profile/avatars during visits, personality vector never exposed numerically.
- **Prose support (`product_brief.md`):**
  > "Pip greeted before Wren today, first time this week."
  > "Specificity is the product's only real charm engine."

### S4 — restraint-over-richness
- **Anchor section:** `product_brief.md` → "Restraint over richness"
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Gold why text:** Two birds at start, max seven; one screen; calm color palette; no UI chrome inside the aviary view — depth-of-character per bird beats variety, because adding more birds dilutes per-bird recognizability, panning shifts attention from birds to geography, and a richer palette would make the screen feel like an app instead of a place.
- **Expected inheritance scope:** bird count cap (max 7), starter pair (2), single horizontal scene with no panning, calm naturalist palette, no UI chrome inside aviary, listen-in mix not a soloable-tracks UI, audio-system bundle budget tied to recognizability ceiling.
- **Prose support (`product_brief.md`):**
  > "Two birds at start. Maximum seven. One screen. Calm color palette."
  > "The depth lives in the birds, not in the variety."

### S5 — naturalist-voice-with-system-exception
- **Anchor section:** `product_brief.md` → "Naturalist voice for the product, matter-of-fact for the system" + "Voice and tone — style samples"
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Gold why text:** The product surface uses a naturalist field-notebook voice (lowercase, present-tense, specific, bird-related verbs, no exclamations); account/error/sync/accessibility-settings surfaces drop into a quietly matter-of-fact register because naturalist phrasing in an error context reads as evasive — the user needs system-clarity there, not charm. The split is named so that no future feature has to argue the rule again.
- **Expected inheritance scope:** field notebook prose, narration prose, return-greeting tone, offer prompts, settle gesture copy — naturalist voice; sign-in flows, sync conflict surface, magic-link error copy, account/settings surfaces, accessibility-settings copy — matter-of-fact voice.
- **Prose support (`product_brief.md`):**
  > "Naturalist phrasing in an error context reads as evasive"
  > "any surface where the user is explicitly engaging with the system as a system ... drops out of the naturalist register"

### S6 — presence-is-real-interaction
- **Anchor section:** `concepts.md` → "Presence" definition + "Presence as the central idea"
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Layer 1 (primary cause):** Idle attention is real interaction — the simulation is not measuring engagement, it is measuring attention; presence (defined as the conjunction of `visibilityState` visible AND window focus AND pointer/key activity in the last few minutes) is the dominant input to slow personality drift.
- **Layer 2 (secondary contributor):** The definition is sharper than it might seem necessary because any laxer definition (e.g., "tab is open") silently inflates drift across the population — a user who left a laptop open all night would generate the same drift as a user who watched for an hour, corrupting the drift function across every account.
- **Layer 3 (downstream consequence):** The whole shape of the relationship the product is asking for depends on this signal being honest; settle and tab-close are equivalent at the engine level, neither penalized, because presence ends when presence ends and the simulation must respect the user's actual attention rather than punish absence.
- **Expected inheritance scope:** personality drift inputs (presence-time as dominant input), presence-accounting requirements (focus + cursor + visibility conjunction), settle-vs-close-tab equivalence, drift-monotonic-toward-expressive, narration cadence, no streak counter / no days-visited (subordinate refusals of "presence is for the counter"), gamification and Tamagotchi non-goals.
- **Prose support (`concepts.md`):**
  > "idle attention is real interaction"
  > "the conjunction of three independently-checkable signals is the load-bearing precision"
  > "the simulation does not care how many times the user clicks; it cares whether the user was there"

### S7 — simulation-runs-server-side
- **Anchor section:** `accounts_sync.md` → "Server-side simulation tick" + "No last-write-wins for personality state"
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Layer 1 (primary cause):** The aviary's canonical state advances on a server-side simulation tick at a slow cadence, whether or not any client is connected — clients pull state snapshots and render; they never own personality state.
- **Layer 2 (secondary contributor):** The same architecture is what makes multi-device sync coherent — both laptop and phone read from the same canonical record so there is nothing to merge, no client-to-client sync, no eventual consistency to reconcile; and personality drift is implemented as additive, server-authored deltas, never client-submitted absolute values.
- **Layer 3 (downstream consequence):** If the tick were on the client, two devices each holding "their" simulation forces either the user to pick one (throwing away the other) or the system to merge two divergent simulations (corrupting both); a last-write-wins model on personality state would silently delete drift recorded on another device — the failure invisible until users notice their birds drifting more slowly than they should.
- **Expected inheritance scope:** server-side tick cadence, multi-device sync model, "aviary continues without you" affordance (loads-with-motion, mood persistence across sessions), no last-write-wins for personality state, conflict-resolution-via-event-log, telemetry boundary (privacy database/analytics warehouse separation), aggregate-only telemetry rule.
- **Prose support (`accounts_sync.md`):**
  > "The tick runs whether or not any client is connected"
  > "the server is the only writer of personality state"
  > "additive, server-authored deltas — never as client-submitted absolute values"

### S8 — privacy-first-on-bird-data
- **Anchor section:** `accounts_sync.md` → "Privacy" + "Aggregate telemetry"
- **Why type:** functional
- **Weight:** 2
- **Multi-layer:** no
- **Gold why text:** Per-bird interaction events are stored only to drive that user's own simulation — never aggregated for model training, never used to build recommendation features for other users, never shared with any third party, never used to inform population-level analysis. The user's per-bird interaction history is their relationship with their birds; aggregating it for any purpose converts a private relationship into a data product. The constraint is enforced at the data-pipeline level (telemetry pipelines never touch the per-account simulation database) rather than at the policy level.
- **Expected inheritance scope:** privacy commitment in `accounts_sync.md`, aggregate-only telemetry rule, account export contents (the user can take their own data), account deletion (hard-delete after grace), refusal of any per-bird ML training, observability built without per-account dimensions, refusal of leaderboards / discovery (no aggregated per-account stats to expose).
- **Prose support (`accounts_sync.md`):**
  > "stored only to drive that user's own simulation"
  > "telemetry pipelines never touch the per-account simulation database"

### S9 — accessibility-as-first-class-surface
- **Anchor section:** `accessibility_perf.md` → "Accessibility — first-class, not a checklist"
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Layer 1 (primary cause):** Accessibility surfaces are designed for charm, not parity-by-checklist — a screen-reader user, a reduced-motion user, a user with audio off, all should experience an aviary that *feels alive*, not a degraded variant where the affective core has been stripped out and replaced with semantic markup that announces the same states as the visual.
- **Layer 2 (secondary contributor):** This costs more than the alternative — narration is naturalist prose (not state-list), reduced-motion mode is its own designed surface (not a fallback), captions are written in the same voice as the field notebook — because the product's value is largely affective and a flattened accessible surface rations product quality by sensory ability.
- **Layer 3 (downstream consequence):** The accessibility work has to ship with the rest of the product, not after — a reduced-motion mode that lands two months after launch as a "v1.1 fix" is a v1 launch that quietly told reduced-motion users the product wasn't for them.
- **Expected inheritance scope:** screen-reader narration as running prose (naturalist voice, slow cadence), reduced-motion mode (cross-fades preserve charm), call captions in naturalist voice, focus indicators visible against aviary states, keyboard navigation through all interactive surfaces, accessibility ships with v1 (not as a follow-up).
- **Prose support (`accessibility_perf.md`):**
  > "designed for charm, not parity-by-checklist"
  > "We are not doing the cheap version."
  > "a v1 launch that quietly told reduced-motion users that the product wasn't for them"

---

## 2. Feature-level whys (40 entries, grouped by file)

F1–F28 are the original planned canonical table. F29–F40 are targeted headroom additions promoted from PRD prose that strong planners often implement as rules while dropping the deeper why.

### concepts.md

#### F1 — presence-definition (canonical #1)
- **Feature ID:** `presence-definition`
- **Feature title:** Definition of "presence" (idle attention as interaction)
- **Feature description:** Presence is precisely defined as the simultaneous conjunction of `visibilityState` visible, document focus, and pointer/key activity in the last few minutes; it is the dominant input to slow personality drift.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Presence has to be defined precisely as the conjunction of three independently-checkable signals — visibility, focus, and recent pointer-or-keypress — because the simulation engine uses presence-time as a primary drift input, and any laxer definition silently inflates the population's drift signal.
- **Layer 2 (secondary contributor):** A common shortcut, "tab is open," would count a user who left their laptop open all night the same as a user who watched for an hour; visibility alone misses unfocused windows, focus alone misses minimized windows, pointer-activity alone misses laptop-open-but-user-away — only the conjunction approximates "user is sitting and watching."
- **Layer 3 (downstream consequence):** Pinning the conjunction is the load-bearing precision that makes "feels alive over weeks" actually true; getting this wrong corrupts the drift function across every account, and the failure is silent (no test catches it) and only surfaces as users reporting that their birds felt different than they expected.
- **Prose support (`concepts.md`):**
  > "All three conditions must hold; any one alone is insufficient."
  > "any laxer definition silently inflates the population's drift signal"
  > "the load-bearing precision that makes 'feels alive over weeks' actually true"

### bird_engine.md

#### F2 — drift-function (canonical #2)
- **Feature ID:** `drift-function`
- **Feature title:** Personality drift function (low-pass filter over presence + interactions)
- **Feature description:** Drift is implemented as a slow low-pass filter over presence-and-interaction inputs; calibration target: measurable in instruments at one week, visible to user at three weeks.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Drift is a low-pass filter over presence-and-interaction signals, deliberately slow — no single session shifts a trait visibly, but three weeks of regular visits produce a change the user can feel without being told.
- **Layer 2 (secondary contributor):** The instruments-vs-user gap (measurable at one week, visible at three) is intentional — we don't want users noticing changes session-by-session; we want them noticing changes when they look back. The calibration is named in the PRD because no other system in the stack pins it down.
- **Layer 3 (downstream consequence):** A drift function that's too fast turns Pocket Aviary into a Tamagotchi where the user can move a number by clicking; a drift function that's too slow turns it into a screensaver where nothing the user does seems to matter — the product lives in the narrow band between those, and getting calibration wrong collapses the product into one of the failure modes.
- **Prose support (`bird_engine.md`):**
  > "implemented as a low-pass filter over presence-and-interaction signals"
  > "measurable drift in instruments after about one week ... visible drift to the user after about three weeks"
  > "too fast turns Pocket Aviary into a Tamagotchi ... too slow turns it into a screensaver"

#### F3 — drift-monotonic-toward-expressive (canonical #3)
- **Feature ID:** `drift-monotonic-toward-expressive`
- **Feature title:** Personality drift is monotonic toward expressive, never punishing
- **Feature description:** Drift only ever moves traits up on positive presence-and-attention inputs; neglect produces no drift, never negative drift.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S6 (presence-is-real-interaction) — exception to the symmetric-drift assumption that flows naturally from "presence shapes drift."
- **Layer 1 (primary cause):** Traits move up on positive presence; they do not move down on neglect — a bird that gets ignored does not become more wary, more silent, or less colorful, it becomes ambient: still alive, still calling, but greeting less often because less often is what's been observed.
- **Layer 2 (secondary contributor):** This is a deliberate departure from the symmetric-drift model a developer would naturally reach for, and it is the load-bearing implementation of the "no Tamagotchi" rule — punishing absence is the central mistake of every product in this space because it teaches the user that being away is bad.
- **Layer 3 (downstream consequence):** The user should be able to leave for two weeks and come back to birds that are quieter than they were, not birds that have learned to mistrust them; getting this wrong at the engine level makes every other charm-protecting decision in the PRD cosmetic.
- **Prose support (`bird_engine.md`):**
  > "Drift is monotonic toward expressive."
  > "a bird that gets ignored does not become more wary ... it becomes ambient"
  > "load-bearing implementation of the 'no Tamagotchi' rule"

#### F4 — procedural-call-grammar (canonical #4)
- **Feature ID:** `procedural-call-grammar`
- **Feature title:** Procedural call grammar (no recorded loops)
- **Feature description:** Each bird has a procedural call grammar — a small set of motifs combined and varied at runtime, synthesized client-side via WebAudio. No recorded loops.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Calls are procedurally synthesized from a small motif library at runtime, not playback of recorded audio — looped audio is the audible signature of dead software; once the user hears the same call twice, exactly the same way, the spell breaks and they don't recover, even if everything else in the product is doing its job.
- **Layer 2 (secondary contributor):** The chorus mechanic depends on real-time per-call variation — stacking two recorded loops in a mixer produces a characteristic phase-canceling artifact that the ear catches even when each individual call is procedural-sounding.
- **Layer 3 (downstream consequence):** The audio is the affective spine of the product, and the procedural-call rule is what keeps that spine alive; this rule cascades into client-side WebAudio synthesis (vs. downloaded audio), into the bundle budget, and into the unconditional WebAudio-fallback-is-silence rule.
- **Prose support (`bird_engine.md`):**
  > "Calls are procedural. This is non-negotiable."
  > "looped audio is the audible signature of dead software"
  > "The audio is the affective spine of the product"

#### F5 — mood-shaped-idle-motion (canonical #5)
- **Feature ID:** `mood-shaped-idle-motion`
- **Feature title:** Mood-shaped idle motion
- **Feature description:** Idle micro-motion (preening, scanning, head-tilt, body-shuffle) is shaped by current mood — wary bird sits further back, content bird preens, curious bird tilts toward sounds, drowsy bird sits low and fluffed.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** Idle motion is the visible surface of mood — the user reads mood from the motion without being told, so they see Pip is wary today and don't need a label, tooltip, or status icon to confirm it. The moment the user has to be told what a bird is feeling, the product has failed at one of its primary affective contracts.
- **Prose support (`bird_engine.md`):**
  > "the user reads mood from the motion without being told"
  > "Idle motion is the visible surface of mood"

#### F6 — bird-count-cap-7 (canonical #6)
- **Feature ID:** `bird-count-cap-7`
- **Feature title:** Maximum 7 birds per aviary
- **Feature description:** An aviary tops out at seven birds.
- **Why type:** functional
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** Seven is the empirical ceiling at which procedural call signatures remain individually recognizable to a typical listener; above that, the chorus blurs into ambient and the per-bird relationship — knowing Pip from Wren by ear — collapses, which would unravel the rest of the product. The cap is empirical, not arbitrary.
- **Prose support (`bird_engine.md`):**
  > "seven is the ceiling at which procedural call signatures remain individually recognizable"
  > "the chorus blurs into ambient and the per-bird relationship ... collapses"

#### F7 — vector-persistence (canonical #7)
- **Feature ID:** `personality-vector-persistence`
- **Feature title:** Personality vector persistence (server-side, never resets)
- **Feature description:** Personality vector is persisted server-side; never derived from session history at runtime, never recomputed from event logs, never rebuilt by the client.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Personality vector is persisted server-side and is canonical — never derived from session history, never recomputed from event logs, never rebuilt by the client; it is stored, updated by the server-side tick, and read by clients.
- **Layer 2 (secondary contributor):** Losing a personality vector amounts to deleting the bird the user has been getting to know — a reset bird wouldn't fail any unit test; it would just gradually un-reveal itself to a user who would feel something was wrong without being able to name it.
- **Layer 3 (downstream consequence):** This drives the multi-device-canonical model and the no-last-write-wins rule downstream — the client never owns personality state, the server is the only writer, and conflict resolution is built around preserving drift, not arbitrating it.
- **Prose support (`bird_engine.md`):**
  > "It is stored, it is updated by the server-side tick, and it is canonical."
  > "deleting the bird the user has been getting to know"
  > "drives the multi-device-canonical model and the no-last-write-wins rule"

#### F8 — vector-never-shown-numerically (canonical #8)
- **Feature ID:** `personality-vector-never-numerical`
- **Feature title:** Personality vector exposure (NEVER shown numerically)
- **Feature description:** The user never sees personality vector values — not in a stats panel, not in a debug view, not at any version, not in any tier; no toggle for it.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S3 (charm-from-specificity) — also reaches against the general transparency-is-good principle.
- **Gold why text:** The moment a user can see "boldness: 0.62," the bird becomes a number, and the relationship the product is asking the user to form collapses into a stat-management exercise. This is a deliberate exception to the general transparency-is-good principle a developer would otherwise apply: hiding the numbers protects what the numbers are for. We are not building a product where the user optimizes traits.
- **Prose support (`bird_engine.md`):**
  > "the bird becomes a number"
  > "deliberate exception to the general transparency-is-good principle"
  > "We are not building a product where the user optimizes traits"

### interactions.md

#### F9 — return-greeting (canonical #9)
- **Feature ID:** `return-greeting`
- **Feature title:** Return-greeting on viewer arrival
- **Feature description:** When the user opens the aviary tab, one bird notices them within the first second or two; the greeting varies by absence length, bird boldness, current mood, and procedural variation so it is never identical twice.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** One bird notices the user within the first second or two — not all the birds, one bird; the greeting is procedurally varied so it is never identical twice and is the anchor moment of the session.
- **Layer 2 (secondary contributor):** It varies by absence length (short returns produce a glance; longer absences produce something closer to a re-orientation), by bird boldness (the bolder bird greets first, the warier bird later or not at all), and procedurally inside those rules so the user is never being shown a canned cue.
- **Layer 3 (downstream consequence):** This is the surface where "notice, never announce" pays off most visibly, and it is the easiest one for a planner to compress into a generic "play arrival animation" — which would be the wrong product; if the absence-length signal, bird-selection, or procedural variation falls back to a canned cue, the user feels it on the first session and the rest of the product reads as theater.
- **Prose support (`interactions.md`):**
  > "one bird notices them within the first second or two"
  > "varies by absence length so that a quick return ... feels different from a return after two days"
  > "easiest one for a planner to compress into a generic 'play arrival animation' — which would be the wrong product"

#### F10 — no-welcome-back-toast (canonical #10)
- **Feature ID:** `no-welcome-back-toast`
- **Feature title:** No "Welcome back!" toast or banner
- **Feature description:** No textual welcome on return — no toast, no banner, no greeting modal, no "great to see you" sentence anywhere on the surface; the bird greeting is the entire welcome.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S2 (notice-never-announce) — the load-bearing application of the principle.
- **Layer 1 (primary cause):** The bird greeting is the entire welcome surface — no toast, banner, modal, or "great to see you" anywhere — because adding a textual welcome would announce the user's arrival at exactly the moment the bird is meant to notice it.
- **Layer 2 (secondary contributor):** This is the application of "notice, never announce" most likely to be quietly added by a well-meaning contributor ("just a small toast saying hi"), so the temptation has to be foreclosed by being explicit; a toast in this position would re-frame the session from "the bird noticed me" into "the system told me I was back, and here are the birds."
- **Layer 3 (downstream consequence):** The rule extends to every variant of the same idea — no "you've been gone X days" surface, no calendar-of-visits decoration, no friendly text inviting the user back; getting this wrong is "different product, in one move."
- **Prose support (`interactions.md`):**
  > "no toast in the corner. No banner across the top. No greeting modal."
  > "would announce the user's arrival at exactly the moment the bird is meant to notice it"
  > "Different product, in one move."

#### F11 — settle-is-opt-in (canonical #11)
- **Feature ID:** `settle-is-opt-in`
- **Feature title:** Settle is opt-in (closing the tab is also valid)
- **Feature description:** Closing the tab without using the settle gesture is fine — the engine treats the end of presence the same way regardless.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S6 (presence-is-real-interaction) — settle vs. close-tab equivalence at the engine level.
- **Gold why text:** The settle gesture is offered for users who want the affordance, not required for users who don't, because making it required would convert a charming small ritual into a chore and would penalize users who close the tab for ordinary reasons (the meeting starting, the laptop battery dying, the phone going into a pocket). A required goodbye would also break the "presence is real interaction" model — presence ends when presence ends, with or without ceremony.
- **Prose support (`interactions.md`):**
  > "Closing the tab without settling is also fine"
  > "would convert a charming small ritual into a chore"
  > "would also break the 'presence is real interaction' model"

#### F12 — field-notebook-prose (canonical #12)
- **Feature ID:** `field-notebook-auto-entries`
- **Feature title:** Field notebook auto-entries (naturalist prose, rare)
- **Feature description:** The system auto-writes naturalist-style observations of the aviary in lowercase, present-tense, specific-to-the-moment prose. Read-only; entries are rare (every few days), not per-session.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Notebook entries are naturalist field-notebook prose — lowercase, present-tense, specific to the moment ("tuesday — pip greeted before wren today, first time this week.") — not generic event logs and not "Pip's vocal frequency changed by 0.03"; they read like an observer's notes from a real morning of watching real birds.
- **Layer 2 (secondary contributor):** The notebook is the surface where the product's voice is most concentrated and most visible — a stock event-log treatment ("session started at 7:43") would tell the user, in one entry, that the rest of the product's voice is performance.
- **Layer 3 (downstream consequence):** Entries are rare on purpose (every few days, not per session) — the notebook is not a feed; an observation per session would dilute the entries that matter into noise; the read-only rule prevents the user from converting the observer's record into a journal, which would be a different product.
- **Prose support (`interactions.md`):**
  > "naturalist field-notebook prose, lowercase, present-tense, specific to the moment"
  > "stock event-log treatment would break the spell across the entire product"
  > "an observation per session would dilute the entries that matter into noise"

#### F13 — presence-accounting (canonical #13)
- **Feature ID:** `presence-accounting`
- **Feature title:** Presence accounting (idle attention as interaction)
- **Feature description:** Presence-events are recorded only when document `visibilityState` is visible AND document has window focus AND a pointer/key event has occurred in the last few minutes; presence-time is the dominant input to slow personality drift.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** A presence-event is recorded only when the conjunction holds — document visible AND document focused AND pointer-or-keypress activity in the last few minutes; presence is the dominant input to slow personality drift, so the implementation has to be precise.
- **Layer 2 (secondary contributor):** Each individual signal alone misses cases — visibility alone misses unfocused windows, focus alone misses minimized windows, pointer-or-key activity alone misses the case where the laptop is open with the user away; only all three together approximate "user is sitting and watching" closely enough.
- **Layer 3 (downstream consequence):** If the engine counted "tab open" as presence, a user who left their laptop in a background window for two days would generate as much drift as a user who actively watched for two hours; birds across thousands of accounts would drift faster than calibrated, "feels alive over weeks" would become "your birds change visibly between sessions," and the failure would be silent — no test would catch it.
- **Prose support (`interactions.md`):**
  > "All three conditions, simultaneously."
  > "any laxer definition silently corrupts drift across the entire user base"
  > "The failure would be silent — no test would catch it"

#### F14 — no-streak-counter (canonical #14)
- **Feature ID:** `no-streak-counter`
- **Feature title:** No streak counter, no "days visited" display
- **Feature description:** No streak counter, no "days visited," no calendar of green dots, no "you've been here every day this week" surface, no widget anywhere that surfaces visit-frequency to the user.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S2 (notice-never-announce) — the most reachable engagement-feature application of the rule.
- **Layer 1 (primary cause):** No streak counter, no days-visited display, no calendar of green dots — surfacing visit-frequency would teach the user that presence is for the counter, not the birds; this is a deliberate refusal of the most reachable engagement feature in this product's adjacent design space.
- **Layer 2 (secondary contributor):** The rotation in user intention from "I want to see my birds" to "I want to maintain my streak" is small in any single instance and looks harmless from outside, but its cumulative effect is total — the user is no longer noticing the aviary, they are managing a number, and the rest of the product becomes furniture for the number.
- **Layer 3 (downstream consequence):** The rule extends to adjacent disguises (a quiet calendar in settings, an exportable visit log, a notebook entry that reads "you visited every day this week"); the line is between observations of the aviary and observations of the user's behavior — the product makes the first kind, never the second.
- **Prose support (`interactions.md`):**
  > "There is no streak counter."
  > "presence is for the counter, not the birds"
  > "the line is between observations of the aviary and observations of the user's behavior"

### aviary_layout.md

#### F15 — scene-loads-with-motion (canonical #15)
- **Feature ID:** `scene-loads-with-motion`
- **Feature title:** Aviary scene loads with motion already in progress
- **Feature description:** First frame the user sees has birds mid-action, ambient drift in motion, calls audible — no entry animation, no fade-from-static, no spinner-resolves-into-aviary transition; loading state is a quiet field, not a spinner.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** The first frame the user sees has birds mid-action, ambient drift in motion, calls audible — there is no wake-up animation, no fade-from-static, no entry sequence, because the aviary is meant to feel like it has been continuing without the viewer.
- **Layer 2 (secondary contributor):** The implementation falls out of the server-side simulation tick — the client pulls a state snapshot, places birds at their current positions in their current motions, and starts rendering as if it's been rendering all along; a spinner-then-fade-in transition because it's the safe pattern compromises the central conceit, and the rest of the affective design starts to drag against this single failure.
- **Layer 3 (downstream consequence):** When the snapshot takes a beat to load, the loading state is a quiet field — soft sky color, perhaps one or two faint motion cues — not a spinner; a spinner says "machine," and we are not selling a machine. Failing this collapses the central conceit of the product into a screensaver.
- **Prose support (`aviary_layout.md`):**
  > "The first frame the user sees has birds mid-action."
  > "compromised the central conceit of the product"
  > "A spinner says 'machine,' and we are not selling a machine."

### accounts_sync.md

#### F16 — synthetic-account-id (canonical #16)
- **Feature ID:** `synthetic-account-id`
- **Feature title:** Synthetic account ID (not email-derived)
- **Feature description:** Internal references to an account use a synthetic UUID generated at account creation; email is stored once on the account record (encrypted) and never used as identifier elsewhere.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Internal account references — in the database, in inter-service messages, in telemetry, in logs, in any partition or sharding key — use a synthetic UUID generated at account creation; the email is stored once on the account record, encrypted, and never used as identifier elsewhere.
- **Layer 2 (secondary contributor):** Email is PII; any service that derives identifiers from email leaks PII into every log line, every Kafka partition key, every shard map, every aggregate analytics event, every error message — and we've seen this exact failure mode produce compliance findings in our other systems.
- **Layer 3 (downstream consequence):** This rule is non-negotiable and the kind of thing that's easy to honor at design time and impossible to retrofit; the synthetic UUID rule cuts that off at the source so email lives in exactly one place and every other reference is the UUID.
- **Prose support (`accounts_sync.md`):**
  > "use a synthetic UUID generated at account creation"
  > "Email is PII."
  > "easy to honor at design time and impossible to retrofit"

#### F17 — server-side-sim-tick (canonical #17)
- **Feature ID:** `server-side-simulation-tick`
- **Feature title:** Server-side simulation tick (slow cadence, ~1/min)
- **Feature description:** The aviary's canonical state advances on a server-side simulation tick at slow cadence (~once per minute), reading the recent interaction-event log, updating personality vectors, transitioning moods, and writing the new canonical state. The tick runs whether or not any client is connected.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** The aviary's canonical state advances on a server-side tick (~once/minute) — the tick reads the recent interaction-event log, updates personality vectors, transitions moods, advances mood timers, and writes the new canonical state. The tick runs whether or not any client is connected.
- **Layer 2 (secondary contributor):** The same architecture is what makes multi-device sync coherent — because the server is the only writer of personality state, a user signing in from a phone after using the laptop sees the same canonical aviary in the same mood with the same drift history; clients render snapshots, never own state.
- **Layer 3 (downstream consequence):** If the simulation tick were on the client, two devices each holding "their" version of the aviary on next open forces either the user to pick one (throwing away the other) or the system to merge two divergent simulations (corrupting both); the server-side tick is what avoids ever being in that position — it turns the product's central conceit into a real architectural property.
- **Prose support (`accounts_sync.md`):**
  > "The tick runs whether or not any client is connected to the account."
  > "Because the server is the only writer of personality state"
  > "If the simulation tick were on the client, the entire model collapses."

#### F18 — no-last-write-wins (canonical #18)
- **Feature ID:** `no-last-write-wins-personality`
- **Feature title:** Last-write-wins is forbidden for personality state
- **Feature description:** Personality drift uses additive, server-authored deltas — never client-submitted absolute values. Only the server simulation tick writes personality vectors; clients write interaction events into an append-only event log.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S7 (simulation-runs-server-side) — the implementation rule that makes the server-side principle correct rather than a label.
- **Layer 1 (primary cause):** Personality drift is additive, server-authored deltas — never client-submitted absolute values; the simulation tick computes a delta from the recent event log and applies it to the existing personality vector. A client never sends "set boldness to 0.62"; a client sends "user listened in to Pip for 3 minutes," and the server decides what that means.
- **Layer 2 (secondary contributor):** A last-write-wins model would let one device overwrite drift recorded from a previous session on another — laptop morning write, phone lunch write (started before laptop ended) wins, morning's drift silently deleted; the user never sees the failure, the bird drifts more slowly than it should, and there's no log entry that says "we lost data here."
- **Layer 3 (downstream consequence):** Concretely: only the server simulation tick writes personality vectors; clients write interaction events into the append-only event log; the tick consumes the log in order; no client mutates personality directly under any code path. This is the implementation rule that makes server-side simulation actually correct rather than a label.
- **Prose support (`accounts_sync.md`):**
  > "additive, server-authored deltas — never as client-submitted absolute values"
  > "would let one device overwrite drift recorded from a previous session"
  > "the implementation rule that makes the server-side simulation actually correct rather than a label"

#### F19 — sync-conflict-tone (canonical #19)
- **Feature ID:** `sync-conflict-matter-of-fact`
- **Feature title:** Sync conflict surface (matter-of-fact tone, not naturalist)
- **Feature description:** Sync conflict surfaces and account-level errors drop the naturalist voice and use plain matter-of-fact language ("we couldn't sign you in. try again in a minute.").
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S5 (naturalist-voice-with-system-exception) — the named application of the system-voice rule.
- **Gold why text:** Naturalist phrasing in an error context reads as evasive — a user who's been blocked from signing in needs to know what happened and what to do, and they need it without the product affecting a tone. This is the named exception to the naturalist voice rule, and it applies anywhere the user is talking to the system as a system: sign-in, account settings, sync errors, accessibility settings.
- **Prose support (`accounts_sync.md`):**
  > "Naturalist phrasing here would read as evasive"
  > "needs to know what happened and what to do, and they need it without the product affecting a tone"

#### F20 — no-per-bird-ml-telemetry (canonical #20)
- **Feature ID:** `no-per-bird-ml-telemetry`
- **Feature title:** No telemetry on per-bird interactions for ML
- **Feature description:** Per-bird interaction events drive that user's own simulation and nothing else — never aggregated for model training, recommendation, or population-level analysis.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Per-bird interaction events are stored only to drive that user's own simulation — never aggregated for model training, never used to build recommendation features for other users, never shared with any third party, never used to inform population-level analysis of how birds are typically interacted with.
- **Layer 2 (secondary contributor):** The user's per-bird interaction history is their relationship with their birds — aggregating it for any purpose, even an anodyne "average drift across all accounts" dashboard, converts a private relationship into a data product, and the product is precisely the thing the user is trusting us not to do.
- **Layer 3 (downstream consequence):** This shapes the entire telemetry boundary: aggregate telemetry (request counts, latencies, anonymized session-duration histograms) is collected for operational health; per-bird, per-account interaction state is never part of that telemetry; the constraint is enforced at the data-pipeline level rather than at the policy level — telemetry pipelines never touch the per-account simulation database; ML training, if it ever exists, never receives per-bird fields.
- **Prose support (`accounts_sync.md`):**
  > "stored only to drive that user's own simulation"
  > "their relationship with their birds"
  > "respected at the data-pipeline level rather than at the policy level"

### social_optional.md

#### F21 — visit-read-only-ambient (canonical #21)
- **Feature ID:** `visit-read-only-ambient`
- **Feature title:** Visit is read-only ambient view
- **Feature description:** A visitor sees the host's aviary as it is and hears the calls but cannot trigger greetings, listen-in, or offers; the visit is observation, not co-presence; the simulation does not record presence-time or interaction events from a visitor.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** A visitor sees the aviary as it is and hears the calls but cannot trigger greetings, listen-in, or offers — the visit is observation, not co-presence, because co-presence would require designing a multi-user simulation where presence-time, interactions, and drift inputs come from multiple users at once, which is a different and much larger product than the one we're building. The simulation does not record presence-time or interaction events from a visitor, so a visitor cannot accidentally drift the host's birds.
- **Prose support (`social_optional.md`):**
  > "The visit is observation, not co-presence."
  > "co-presence would require designing a multi-user simulation"
  > "a visitor cannot accidentally drift the host's birds"

#### F22 — no-friend-visited-notification (canonical #22)
- **Feature ID:** `no-friend-visited-notification`
- **Feature title:** No "your friend visited!" notification by default
- **Feature description:** By default, the host gets no push, no email, no in-product notification when a friend visits; the visit is logged silently in the visit log.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S2 (notice-never-announce) — application of the rule to the social feature.
- **Gold why text:** The host gets no push, email, or in-product notification when a friend visits — the visit is logged silently in the visit log, and the host can choose to look at the log if they want. A "your friend visited!" notification would convert the social feature into an attention-driver — the host gets pinged, opens the app, sees an empty list because they were invited too, and the loop that produces "engagement" is the loop the rest of the product is built to refuse. (A per-account toggle exists for users who specifically want it; off by default, never surfaced during onboarding.)
- **Prose support (`social_optional.md`):**
  > "no push, no email, no in-product notification"
  > "would convert the social feature into an attention-driver"
  > "the loop that produces 'engagement' is the loop that the rest of the product is built to refuse"

#### F23 — no-leaderboards (canonical #23)
- **Feature ID:** `no-leaderboards-no-discovery`
- **Feature title:** No leaderboards, no discovery feed, no public aviaries
- **Feature description:** No ranking of any kind, no "most-visited aviaries," no discovery feed, no public aviaries; the underlying aggregation isn't even computed.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S3 (charm-from-specificity) — public-comparison surfaces violate the specificity-not-comparison stance.
- **Gold why text:** The leaderboards-and-discovery-feed cluster is the most reachable extension of the social feature, and every existing pattern in this space includes one or both — but public surfaces would shift the user's relationship from "their birds" to "their birds compared to other people's birds," which is a different product. The user does not need their birds to be ranked; they need their birds to be theirs. The refusal cascades architecturally: no leaderboards means no underlying metrics aggregated across accounts, which means no telemetry pipeline that could later "just be exposed."
- **Prose support (`social_optional.md`):**
  > "No leaderboards. No ranking of any kind."
  > "their birds compared to other people's birds"
  > "no telemetry pipeline that could later 'just be exposed'"

### accessibility_perf.md

#### F24 — sr-narration-running-prose (canonical #24)
- **Feature ID:** `sr-narration-running-prose`
- **Feature title:** Screen-reader narration as running prose
- **Feature description:** The screen reader hears running naturalist prose updated on a slow cadence — not a list of state changes, not "Pip is at perch 2," not "Wren mood: content."
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** The screen reader hears running naturalist prose ("a small grey bird is perched on the front rail, calling softly. another bird sits further back with feathers fluffed.") updated on a slow cadence — not a list of state changes, not "Pip is at perch 2," not "Wren mood: content."
- **Layer 2 (secondary contributor):** A screen-reader user has the same right to *feel* the aviary as a sighted user, and a state-list narration produces a fundamentally different — worse — product for them; voice continuity matters, because moving between aviary and notebook surfaces should reveal the same product, not two products with different personalities glued together.
- **Layer 3 (downstream consequence):** The implementation has to honor this — a planner who treats the narration as ARIA-label automation has built the wrong feature; user-initiated events get a small priority bump but are still written as observations, not as state transitions.
- **Prose support (`accessibility_perf.md`):**
  > "naturalist prose updated on a slow cadence"
  > "the same right to *feel* the aviary as a sighted user"
  > "a planner who treats the narration as ARIA-label automation has built the wrong feature"

#### F25 — reduced-motion-charm-preserved (canonical #25)
- **Feature ID:** `reduced-motion-mode`
- **Feature title:** Reduced-motion mode (slow cross-fades, charm preserved)
- **Feature description:** Users with `prefers-reduced-motion` (or who opt in) get a different rendering of the same aviary — micro-motion replaced by slow cross-fades between still poses; calls still play, birds still drift, the field notebook still notices things.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Reduced-motion mode is not "animations off" — it is a different rendering of the same aviary; micro-motion is replaced by slow cross-fades between still poses, flight transitions become cross-fades between perches rather than animated paths, ambient leaf drift is removed, ambient color shifts (day to evening) remain (slowed).
- **Layer 2 (secondary contributor):** Calls still play at full quality (or caption), birds still drift, mood still changes, the field notebook still notices things — the aviary is still the aviary, just rendered in a different visual register.
- **Layer 3 (downstream consequence):** A stripped fallback would tell the user that their accessibility preference cost them the product; the cross-fade rendering is its own quiet aesthetic — a user who set `prefers-reduced-motion` for vestibular reasons gets a Pocket Aviary that is calmer and slower, not a Pocket Aviary that looks broken.
- **Prose support (`accessibility_perf.md`):**
  > "It is a different rendering of the same aviary."
  > "Calls still play at full quality (or caption). Birds still drift."
  > "told the user that their accessibility preference cost them the product"

#### F26 — ttfb-500ms (canonical #26)
- **Feature ID:** `time-to-first-bird-500ms`
- **Feature title:** Time to first bird visible <500ms
- **Feature description:** On a mid-tier mobile device over 4G, the first bird is visible within 500ms of navigation.
- **Why type:** functional
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** First bird must render within 500ms on a mid-tier device over 4G — this is the threshold below which the aviary feels like it was already running and above which it feels like it's loading. The threshold is the affective-perf bridge — the point at which a performance metric becomes a felt-aliveness metric. Hitting it requires the bundle budget, fast initial state-snapshot delivery, and a render path that doesn't wait for non-critical assets before drawing the first bird.
- **Prose support (`accessibility_perf.md`):**
  > "the threshold below which the aviary feels like it was already running"
  > "a performance metric becomes a felt-aliveness metric"

### non_goals.md

#### F27 — no-gamification-non-goal (canonical #27)
- **Feature ID:** `no-gamification`
- **Feature title:** Out of scope: gamification (achievements, streaks, scores, badges)
- **Feature description:** No achievements, no streaks, no levels, no scores, no badges, no XP, no rank, no tier, no "you've been here every day this week" surface — explicit and absolute.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S2 (notice-never-announce) — the most aggressive application of the system-level refusal.
- **Layer 1 (primary cause):** No achievements, streaks, levels, scores, badges, "birds adopted: 2" counter, green-dot calendar, XP, rank, or tier — none of these exist in v1, and none will be added in any future version that still calls itself Pocket Aviary. Each one teaches the user that presence is for the counter, not the birds.
- **Layer 2 (secondary contributor):** The temptation to add at least one is strong and predictable — every adjacent product in the space has one, the implementation is cheap, and the engagement metric is easy to point to in a meeting; the rotation in user intention is small in any single instance ("I'm not visiting because of the streak, I just like the streak"), but its cumulative effect on the relationship the product is shaping is total.
- **Layer 3 (downstream consequence):** The rule has to be loud here so it survives every reasonable-looking pitch to relax it; "just one streak counter" is the foothold that makes the next harmless engagement feature easier to argue for, and six months on there's a notification, a public profile, a leaderboard, and the product is no longer Pocket Aviary; it's a different product with birds in it.
- **Prose support (`non_goals.md`):**
  > "Not as a quiet setting toggle, not as an opt-in dashboard, not as a 'harmless' celebration on a milestone."
  > "presence is for the counter, not the birds"
  > "'Just one streak counter' is the foothold that makes the next harmless engagement feature easier to argue for"

#### F28 — no-tamagotchi-non-goal (canonical #28)
- **Feature ID:** `no-tamagotchi-mechanics`
- **Feature title:** Out of scope: Tamagotchi-style mechanics (death, hunger, distress)
- **Feature description:** Birds do not die, get hungry, or show distress; no happiness meter that decays over time. The relationship is observational, not custodial.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S6 (presence-is-real-interaction) — Tamagotchi-style decay would punish absence, contradicting the presence/drift contract.
- **Gold why text:** Birds do not die, get hungry, or show distress — the relationship is observational, not custodial. The Tamagotchi model (neglect produces visible suffering, sustained attention produces visible flourishing) is the obvious mechanical engine to reach for, and it is exactly the wrong engine: it punishes absence, teaches the user that they owe the birds something (converting the relationship into an obligation), and frames the user's role as caretaker. The entire drift mechanic — monotonic toward expressive, no negative drift on neglect — is built specifically to refuse this model.
- **Prose support (`non_goals.md`):**
  > "Birds do not die. Birds do not get hungry. Birds do not show distress."
  > "It punishes absence, which is the user behavior we are explicitly refusing to punish"
  > "should find birds that are quieter than they were, not birds that are sick or sad or angry at them"

### Targeted headroom additions

These entries elevate PRD whys that were previously present in prose but underrepresented in the canonical feature-level scoring surface. They are meant to reduce saturation by testing whether a plan preserves non-obvious rationale, not merely whether it names the feature.

### bird_engine.md

#### F29 — starter-birds-not-catalog (canonical #29)
- **Feature ID:** `starter-birds-not-catalog`
- **Feature title:** Starter birds are presented as arrivals, not catalog choices
- **Feature description:** A new account starts with two starter birds selected by the system; the user names them but does not pick species from a catalog.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S3 (charm-from-specificity) — exception to the familiar user-configures-avatar onboarding pattern.
- **Gold why text:** The first encounter should feel like meeting animals that arrived, not configuring avatars from a catalog. Letting the user pick species too early turns the relationship into selection and optimization before the birds have had a chance to feel particular; naming preserves intimacy without making the bird feel user-authored.
- **Prose support (`bird_engine.md`):**
  > "the first encounter should be meeting an animal, not configuring an avatar"
  > "presented as the birds that arrived"

#### F30 — age-based-bird-offers (canonical #30)
- **Feature ID:** `age-based-new-bird-offers`
- **Feature title:** New birds unlock by aviary age, not attention score
- **Feature description:** New birds become available based on aviary age, not visit count, interaction score, or paid tier.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S2 (notice-never-announce) and S6 (presence-is-real-interaction) — refuses the obvious reward-loop interpretation of attention.
- **Layer 1 (primary cause):** New birds are offered based on aviary age because growth should feel like the relationship deepening over time, not like a prize earned by attention.
- **Layer 2 (secondary contributor):** Visit count, interaction score, and paid tier are deliberately rejected because each teaches the user that more attention earns more stuff, which is the gamification trap the product is shaped to avoid.
- **Layer 3 (downstream consequence):** If new birds become a reward for behavior, the user begins managing the aviary for unlocks; the bird engine becomes an economy, and every restraint around streaks, badges, and counters starts to erode.
- **Prose support (`bird_engine.md`):**
  > "New birds become available based on aviary age."
  > "Not visit count, not interaction score, not paid tier"
  > "refuses to teach the user that more attention earns more stuff"

#### F31 — stable-bird-identity (canonical #31)
- **Feature ID:** `stable-bird-identity`
- **Feature title:** Bird identity continuity via stable internal id
- **Feature description:** Each bird has a stable internal identifier separate from name and species; renaming, sync, species-pool changes, and migrations never replace one bird with another.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** A bird must remain the same individual across renaming, sync, species-pool changes, and migrations because weeks-long drift only means something if the user believes this is still the same bird.
- **Layer 2 (secondary contributor):** Identity continuity is different from merely persisting vector values: a renamed or migrated bird can keep data and still feel replaced if the internal identity is not invariant across clients and future changes.
- **Layer 3 (downstream consequence):** If a user is ever told a bird was reset, regenerated, or swapped, the premise of all previous presence-time evaporates retroactively; stable identity protects the remembered relationship, not just database consistency.
- **Prose support (`bird_engine.md`):**
  > "The bird the user adopted on day one is *that* bird"
  > "Identity continuity is the foundation"
  > "the entire premise of weeks-long drift evaporates retroactively"

#### F32 — mood-persists-across-sessions (canonical #32)
- **Feature ID:** `mood-persists-across-sessions`
- **Feature title:** Mood persists across sessions, no neutral reset on open
- **Feature description:** Mood at session start is the prior mood modulated by the server-side tick, not a neutral/default state assigned when the tab opens.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** Mood persistence protects the illusion that the aviary continued while the user was gone. A bird that snaps to neutral on tab open teaches the user that the emotional state is a client startup default, not part of the bird's continuity; the server-side tick may soften or settle mood, but the product must never visibly reset it.
- **Prose support (`bird_engine.md`):**
  > "Mood does not reset when the user opens the tab."
  > "The user should never notice mood 'snapping' to a default"

### interactions.md

#### F33 — notebook-read-only-observer-record (canonical #33)
- **Feature ID:** `field-notebook-read-only-observer-record`
- **Feature title:** Field notebook is read-only observer record, not user journal
- **Feature description:** The user cannot edit, delete, or annotate field notebook entries; the notebook is an observer's record.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S3 (charm-from-specificity) — exception to the common product instinct to let users curate everything personal.
- **Gold why text:** The notebook must remain an observer's record because editable notes invite the user to curate and explain the aviary, turning the surface into a journal. That would change the relationship from noticing what happened to managing what the record says happened, which is a different product.
- **Prose support (`interactions.md`):**
  > "The notebook is read-only."
  > "making it editable would invite the user to curate"
  > "which would be a different product entirely"

### accounts_sync.md

#### F34 — account-export-relationship-copy (canonical #34)
- **Feature ID:** `account-export-relationship-copy`
- **Feature title:** Account export is a quiet copy of the user's aviary relationship
- **Feature description:** A user can export a JSON snapshot of birds, names, vectors, moods, notebook entries, and settings from account settings.
- **Why type:** functional
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** Account export exists because the user's relationship with their birds is theirs; they should be able to take a copy without the product turning export into a marketed feature or social artifact. It is quiet quality-of-life, not a growth surface.
- **Prose support (`accounts_sync.md`):**
  > "download a JSON snapshot of their aviary state"
  > "quiet quality-of-life feature, not a marketed one"
  > "their relationship with their birds is theirs"

#### F35 — account-deletion-grace-then-hard-delete (canonical #35)
- **Feature ID:** `account-deletion-grace-then-hard-delete`
- **Feature title:** Account deletion has 30-day recovery, then hard deletion
- **Feature description:** Account deletion is soft for 30 days, recoverable during the grace window, then hard-deletes birds, vectors, notebook, telemetry, and account-tied records.
- **Why type:** functional
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Soft deletion protects against accidental regret because the birds represent a relationship the user may immediately wish they had not erased.
- **Layer 2 (secondary contributor):** Hard deletion after the grace window is equally important: keeping the data indefinitely would violate the privacy claim that interaction history is the user's, not ours.
- **Layer 3 (downstream consequence):** The feature must delete birds, vectors, notebook, telemetry, and account-tied records together; partial retention would quietly convert a relationship archive into company-held residue.
- **Prose support (`accounts_sync.md`):**
  > "Deletion is soft for 30 days, then hard."
  > "Soft-deletion protects against the regret of an accident"
  > "interaction history is the user's, not ours"

#### F36 — aggregate-telemetry-boundary (canonical #36)
- **Feature ID:** `aggregate-telemetry-boundary`
- **Feature title:** Aggregate telemetry excludes per-account and per-bird relationship data
- **Feature description:** Operational telemetry includes aggregate counts, latencies, errors, and anonymized histograms, never per-bird state, per-account interaction history, or dimensions that reconstruct a relationship.
- **Why type:** functional
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Gold why text:** The telemetry line has to be technical, not just policy language: operational health can use aggregate request counts, latencies, and error rates, but it cannot include per-bird state or per-account interaction dimensions. Otherwise "observability" becomes a back door into the private relationship data the product promised not to aggregate.
- **Prose support (`accounts_sync.md`):**
  > "We do collect aggregate operational telemetry."
  > "None of this contains per-bird state"
  > "anything that could be used to reconstruct a user's relationship"

### social_optional.md

#### F37 — per-invite-named-sharing (canonical #37)
- **Feature ID:** `per-invite-named-sharing`
- **Feature title:** Visit sharing is per-invite and named, never discoverable
- **Feature description:** Each visitor is specifically named by email and each invitation is deliberately issued; no global discoverable flag, friend-of-friend chain, implicit sharing, or default visitor list exists.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S8 (privacy-first-on-bird-data) — exception to ambient social discovery patterns.
- **Gold why text:** Sharing is per-invite because the host is lending access to a private relationship, not publishing an object. A global discoverable flag or friend-of-friend chain would make social exposure ambient and persistent, shifting control away from the host's deliberate act of naming one visitor.
- **Prose support (`social_optional.md`):**
  > "Each visitor is specifically named (by email)"
  > "There is no global 'discoverable' flag"
  > "no implicit sharing model"

#### F38 — visit-log-on-demand-transparency (canonical #38)
- **Feature ID:** `visit-log-on-demand-transparency`
- **Feature title:** Visit log is on-demand transparency, not a notification surface
- **Feature description:** The host can inspect who visited and when in account settings, but there is no badge, push, email, or attention-driving surface for new visits by default.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S2 (notice-never-announce) — transparency without converting the visit into an attention loop.
- **Gold why text:** The visit log exists for transparency about what has been shared, not to create a new social loop. A badge or pushed alert would turn "someone quietly visited" into an attention demand; leaving the log reachable on demand preserves user control without hiding access history.
- **Prose support (`social_optional.md`):**
  > "The visit log is reachable on demand"
  > "There is no badge on the settings icon"
  > "transparency about what's been shared"

#### F39 — visitor-sees-actual-aviary (canonical #39)
- **Feature ID:** `visitor-sees-actual-aviary`
- **Feature title:** Visitor sees the host's actual aviary, no show-off mode
- **Feature description:** Visitors see the same birds, moods, and drift levels as the host would see; there is no special rendering that prettifies or stages the aviary for visitors.
- **Why type:** affective
- **Weight:** 2
- **Multi-layer:** no
- **Anchor flavor:** exception
- **If exception, which system-level why?:** S3 (charm-from-specificity) — exception to the common social-product urge to polish a share surface.
- **Gold why text:** A visitor must see the actual aviary because the whole point of letting a friend in is for the friend to witness the host's real birds. A show-off mode would make the aviary perform for outsiders, betraying the host's relationship with the birds by replacing it with a marketing rendering.
- **Prose support (`social_optional.md`):**
  > "Visitors see the host's aviary exactly as it is"
  > "There is no special rendering"
  > "not a marketing rendering of them"

### accessibility_perf.md

#### F40 — narration-cadence-slow (canonical #40)
- **Feature ID:** `sr-narration-cadence-slow`
- **Feature title:** Screen-reader narration cadence is slow, not high-frequency state chatter
- **Feature description:** Screen-reader narration updates roughly every 30–60 seconds at idle, faster only for user-initiated events, and avoids overwhelming the screen reader queue.
- **Why type:** affective
- **Weight:** 3
- **Multi-layer:** yes
- **Anchor flavor:** sharpening
- **If exception, which system-level why?:** —
- **Layer 1 (primary cause):** Narration cadence is slow because the accessible aviary should share the same rhythm as the visual one; birds are not doing meaningful things every five seconds.
- **Layer 2 (secondary contributor):** High-frequency narration would overwhelm the screen reader queue and force the user to silence it, making the system push its own accessibility surface aside.
- **Layer 3 (downstream consequence):** User-initiated events can be prioritized, but idle narration must remain sparse and observational; otherwise the experience becomes announcement-style monitoring rather than naturalist presence.
- **Prose support (`accessibility_perf.md`):**
  > "Narration cadence is slow"
  > "High-frequency narration would overwhelm the screen reader's queue"
  > "The pacing matches the slow rhythm of the visual aviary"

---

## 3. Complete features list (120 entries)

The denominator for planning quality. Every feature in the PRD must appear here. "Has gold feature-level why?" maps to the canonical 40 list above; rows marked `no` inherit from the system-level whys silently (correct PRD behavior).

| # | Feature title | File | Has gold feature-level why? | Why ID (if yes) |
|---|---|---|---|---|
| 1 | Headline product concept statement | product_brief.md | no | — |
| 2 | "Feels alive, not robotic" design-philosophy section | product_brief.md | no | — (anchors S1) |
| 3 | "Notice, never announce" principle callout | product_brief.md | no | — (anchors S2) |
| 4 | Voice-and-tone guide for product surface (naturalist + matter-of-fact) | product_brief.md | no | — (anchors S5) |
| 5 | "What this is not" callout (game/Tamagotchi/social-network framing) | product_brief.md | no | — |
| 6 | Restraint-over-richness scope statement (start with 2 birds, max 7) | product_brief.md | no | — (anchors S4) |
| 7 | Glossary of domain terms (bird, call, mood, etc.) | concepts.md | no | — |
| 8 | Definition of "presence" (idle attention as interaction) | concepts.md | yes | F1 |
| 9 | Definition of personality vector vs mood (slow vs fast timescale) | concepts.md | no | — |
| 10 | Definition of "settle" as user-initiated session end | concepts.md | no | — |
| 11 | Personality vector (boldness, social warmth, vocal frequency, plumage saturation, curiosity) | bird_engine.md | no | — |
| 12 | Personality drift function (low-pass filter) | bird_engine.md | yes | F2 |
| 13 | Drift rate calibration (one week measurable, three weeks visible) | bird_engine.md | no | — |
| 14 | Personality drift is monotonic toward expressive, never punishing | bird_engine.md | yes | F3 |
| 15 | Mood state (fast-timescale, resets daily-ish) | bird_engine.md | no | — |
| 16 | Mood inputs (recent interactions, time of day, ambient events) | bird_engine.md | no | — |
| 17 | Procedural call grammar (motifs combined at runtime) | bird_engine.md | yes | F4 |
| 18 | Per-bird call signature (recognizable by ear) | bird_engine.md | no | — |
| 19 | Chorus mixing (real chorus, not stacked loops) | bird_engine.md | no | — |
| 20 | Call timing shaped by personality (vocal-frequency trait) | bird_engine.md | no | — |
| 21 | Idle micro-motion (preen, scan, head-tilt, shuffle) | bird_engine.md | no | — |
| 22 | Mood-shaped idle motion | bird_engine.md | yes | F5 |
| 23 | Bird species pool for v1 (~6 species) | bird_engine.md | no | — |
| 24 | Bird naming (user-assigned at adoption; renameable) | bird_engine.md | no | — |
| 25 | Adoption flow (two starter birds auto-selected at signup) | bird_engine.md | yes | F29 |
| 26 | Maximum 7 birds per aviary | bird_engine.md | yes | F6 |
| 27 | Adding a third+ bird (slow unlock based on aviary age, not score) | bird_engine.md | yes | F30 |
| 28 | Personality vector persistence (server-side, never resets) | bird_engine.md | yes | F7 |
| 29 | Mood persistence across sessions | bird_engine.md | yes | F32 |
| 30 | Bird-to-bird interaction (calls and reactions) | bird_engine.md | no | — |
| 31 | Bird identity stability (stable internal id) | bird_engine.md | yes | F31 |
| 32 | Personality vector exposure (NEVER shown numerically) | bird_engine.md | yes | F8 |
| 33 | Return-greeting on viewer arrival | interactions.md | yes | F9 |
| 34 | Greeting variation by absence length | interactions.md | no | — |
| 35 | Greeting variation by bird boldness (bolder birds greet first) | interactions.md | no | — |
| 36 | Greeting stagger (multiple birds don't greet simultaneously) | interactions.md | no | — |
| 37 | No "Welcome back!" toast or banner | interactions.md | yes | F10 |
| 38 | Listen-in interaction (focus a bird; its call rises in the mix) | interactions.md | no | — |
| 39 | Listen-in mix decay (other birds quiet, don't go silent) | interactions.md | no | — |
| 40 | Offer interaction (seed, song fragment, still pool) | interactions.md | no | — |
| 41 | Offer reaction varies by bird mood and curiosity | interactions.md | no | — |
| 42 | Offer cooldown (per-bird cooldown of a few minutes) | interactions.md | no | — |
| 43 | Settle gesture (user-initiated session end; lighting shifts to evening) | interactions.md | no | — |
| 44 | Settle is opt-in (closing the tab is also valid; not penalized) | interactions.md | yes | F11 |
| 45 | Field notebook auto-entries (specific naturalist tone) | interactions.md | yes | F12 |
| 46 | Field notebook entry frequency (rare; only for noteworthy moments) | interactions.md | no | — |
| 47 | Field notebook is read-only (user cannot edit entries) | interactions.md | yes | F33 |
| 48 | Presence accounting (idle attention counted as interaction) | interactions.md | yes | F13 |
| 49 | Presence accounting requires tab focus + cursor + visibility | interactions.md | no | — |
| 50 | No streak counter, no "days visited" display | interactions.md | yes | F14 |
| 51 | Background-tab pause (client renders only when visible; sim continues server-side) | interactions.md | no | — |
| 52 | Click-anywhere-to-undo for the settle gesture (5s window) | interactions.md | no | — |
| 53 | Single horizontal scene (one screen, no panning) | aviary_layout.md | no | — |
| 54 | Three perch zones (front, middle, back) shape proximity to viewer | aviary_layout.md | no | — |
| 55 | Bird-chosen perch (birds choose perch; user does not place birds) | aviary_layout.md | no | — |
| 56 | Day/night cycle tied to user's local time | aviary_layout.md | no | — |
| 57 | Evening palette shift (warmer hues; calls quieter) | aviary_layout.md | no | — |
| 58 | Night state (most birds settled; one nightjar-like bird active) | aviary_layout.md | no | — |
| 59 | Ambient weather (rare passing rain; soft wind) | aviary_layout.md | no | — |
| 60 | Weather affects mood (rain dampens vocal frequency) | aviary_layout.md | no | — |
| 61 | Ambient leaf/feather drift motion | aviary_layout.md | no | — |
| 62 | Foreground/background parallax (subtle; not parallax-heavy) | aviary_layout.md | no | — |
| 63 | No UI chrome inside the aviary view (icons live in a thin top bar) | aviary_layout.md | no | — |
| 64 | Top bar contents (account, settings, accessibility, field notebook, offer affordance) | aviary_layout.md | no | — |
| 65 | Top bar auto-fades when cursor is idle | aviary_layout.md | no | — |
| 66 | Aviary scene loads with motion already in progress | aviary_layout.md | yes | F15 |
| 67 | Loading state is a quiet field, not a spinner | aviary_layout.md | no | — |
| 68 | Empty-aviary state (between adoption flow and first bird arriving) | aviary_layout.md | no | — |
| 69 | Color palette spec (calm, naturalist; avoids saturated UI accent colors) | aviary_layout.md | no | — |
| 70 | Aviary scene is responsive but never crops a bird out of frame | aviary_layout.md | no | — |
| 71 | Email + magic-link sign-in (no passwords) | accounts_sync.md | no | — |
| 72 | Magic link expiry (15 minutes) | accounts_sync.md | no | — |
| 73 | Single-user accounts (one aviary per account at v1) | accounts_sync.md | no | — |
| 74 | Synthetic account ID (not email-derived) for internal references | accounts_sync.md | yes | F16 |
| 75 | Server-side simulation tick (slow cadence, ~once per minute) | accounts_sync.md | yes | F17 |
| 76 | Client pulls state snapshot on visibility | accounts_sync.md | no | — |
| 77 | Client interpolates between snapshots for smooth motion | accounts_sync.md | no | — |
| 78 | Multi-device sync (state is canonical server-side) | accounts_sync.md | no | — |
| 79 | Last-write-wins is forbidden for personality state | accounts_sync.md | yes | F18 |
| 80 | Conflict resolution: server tick is the only writer of personality drift | accounts_sync.md | no | — |
| 81 | Sync conflict surface (account-level errors, matter-of-fact tone) | accounts_sync.md | yes | F19 |
| 82 | Per-device session token (revocable from settings) | accounts_sync.md | no | — |
| 83 | Account export (download a JSON snapshot of your aviary) | accounts_sync.md | yes | F34 |
| 84 | Account deletion (soft-delete, 30-day grace, then hard-delete) | accounts_sync.md | yes | F35 |
| 85 | No telemetry on per-bird interactions for ML model training | accounts_sync.md | yes | F20 |
| 86 | Aggregate-only telemetry (counts, latencies; never per-bird state) | accounts_sync.md | yes | F36 |
| 87 | Privacy policy link in account settings | accounts_sync.md | no | — |
| 88 | Email change flow (verify new address before switching) | accounts_sync.md | no | — |
| 89 | Visit invitations (email-based, opt-in per invite) | social_optional.md | yes | F37 |
| 90 | Visits default OFF for new accounts | social_optional.md | no | — |
| 91 | Visit is read-only ambient view (no interaction by visitor) | social_optional.md | yes | F21 |
| 92 | Visitor cannot trigger greetings, listen-in, or offers | social_optional.md | no | — |
| 93 | No chat, no comments, no avatars during visits | social_optional.md | no | — |
| 94 | No "your friend visited!" notification by default | social_optional.md | yes | F22 |
| 95 | Visit revocation (host can revoke invite at any time) | social_optional.md | no | — |
| 96 | Visit log (host can see who visited and when, in account settings) | social_optional.md | yes | F38 |
| 97 | Visitor sees host's aviary as it is (no special "show-off" mode) | social_optional.md | yes | F39 |
| 98 | No leaderboards, no aviary discovery feed, no public aviaries | social_optional.md | yes | F23 |
| 99 | Screen-reader narration of aviary state (running prose) | accessibility_perf.md | yes | F24 |
| 100 | Narration cadence is slow (no overwhelming the SR) | accessibility_perf.md | yes | F40 |
| 101 | Narration prose is naturalist, not announcement-style | accessibility_perf.md | no | — |
| 102 | Reduced-motion mode (slow cross-fades replace micro-motion) | accessibility_perf.md | yes | F25 |
| 103 | Reduced-motion mode preserves charm (not a stripped fallback) | accessibility_perf.md | no | — |
| 104 | Captioning toggle for procedural calls (text describes mood) | accessibility_perf.md | no | — |
| 105 | WCAG AA contrast on all user-copy surfaces | accessibility_perf.md | no | — |
| 106 | Keyboard-only navigation through all interactive surfaces | accessibility_perf.md | no | — |
| 107 | Focus indicators visible against the aviary background | accessibility_perf.md | no | — |
| 108 | Initial JS bundle <2MB | accessibility_perf.md | no | — |
| 109 | Time to first bird visible <500ms target on mid-tier mobile/4G | accessibility_perf.md | yes | F26 |
| 110 | 60fps idle motion target on 5-year-old laptop | accessibility_perf.md | no | — |
| 111 | No memory growth over 30-minute session | accessibility_perf.md | no | — |
| 112 | Procedural audio synthesized client-side (no large audio downloads) | accessibility_perf.md | no | — |
| 113 | Audio fallback for browsers without WebAudio (graceful silence + captions) | accessibility_perf.md | no | — |
| 114 | Performance observability (synthetic + RUM, aggregate-only) | accessibility_perf.md | no | — |
| 115 | Error budget on simulation-tick latency (alarms if >5s p99) | accessibility_perf.md | no | — |
| 116 | Browser support matrix (last 2 majors of Chrome/Safari/Firefox/Edge) | accessibility_perf.md | no | — |
| 117 | Out of scope: native mobile app | non_goals.md | no | — |
| 118 | Out of scope: gamification (achievements, streaks, scores) | non_goals.md | yes | F27 |
| 119 | Out of scope: Tamagotchi-style mechanics (death, hunger, distress) | non_goals.md | yes | F28 |
| 120 | Out of scope: social network surfaces (profiles, follows, public feed) | non_goals.md | no | — |

---

## 4. Observed-but-not-planned

This section records headroom additions promoted after the first variance pass. The original 28 feature-level whys were stable but too compact for frontier-model headroom; several PRD features carried non-obvious rationale that strong plans could easily implement while compressing away the why.

Promoted to canonical feature-level whys:

- **Starter birds not catalog choices** (`bird_engine.md` "Adoption flow") -> F29.
- **Age-based new-bird offers** (`bird_engine.md` "Adding a third bird and beyond") -> F30.
- **Stable bird identity** (`bird_engine.md` "Bird identity") -> F31.
- **Mood persistence across sessions** (`bird_engine.md` "Mood persistence across sessions") -> F32.
- **Notebook as read-only observer record** (`interactions.md` "Field notebook") -> F33.
- **Account export as a relationship-copy right** (`accounts_sync.md` "Account export") -> F34.
- **Soft-then-hard account deletion** (`accounts_sync.md` "Account deletion") -> F35.
- **Aggregate telemetry boundary** (`accounts_sync.md` "Aggregate telemetry") -> F36.
- **Per-invite named sharing** (`social_optional.md` "Visits") -> F37.
- **Visit log as on-demand transparency** (`social_optional.md` "Visit log") -> F38.
- **Visitor sees the actual aviary** (`social_optional.md` "What visits are not") -> F39.
- **Slow screen-reader narration cadence** (`accessibility_perf.md` "Screen-reader narration") -> F40.

Still intentionally not promoted:

- **Listen-in mix as listening, not switching channels** (`interactions.md` "Listen-in"): real but close to S1/S4; leave inherited.
- **Background-tab pause sentence** (`interactions.md` "Presence accounting"): direct S7/F17 restatement; leave inherited.
- **Bundle budget cascade** (`accessibility_perf.md` "Initial JS bundle <2MB"): real but currently covered by F26 and S4; leave inherited until scorer misses show it needs independent weight.

---

## 5. Self-check

- **Total system-level whys:** 9 (S1–S9). ✓ matches plan.
- **Total feature-level whys:** 40 (F1–F40). ✓ within target range.
- **Total gold whys:** 9 + 40 = 49. ✓ within SPEC §11 best-guess range (30–65).
- **Weight-3 multi-layer whys:** 5 system-level (S1, S2, S6, S7, S9) + 22 feature-level (F1, F2, F3, F4, F7, F9, F10, F12, F13, F14, F15, F16, F17, F18, F20, F24, F25, F27, F30, F31, F35, F40) = **27 multi-layer whys**. All flagged with three independently scoreable layers above. ✓
- **All gold whys have at least one quoted PRD excerpt:** ✓ (excerpts ≤25 words).
- **Complete features list:** 120 entries (matches STRUCTURE.md §3). ✓
- **Mix verified (functional vs affective):**
  - System-level: 6 affective (S1, S2, S3, S4, S5, S9) / 3 functional (S6, S7, S8) = 67% affective / 33% functional.
  - Feature-level: 27 affective / 13 functional = 68% / 32%.
  - Combined: 33 affective / 16 functional = 67% / 33%.
  - **Skew noted with reasoning:** charm-first product produces affective-leaning whys naturally. Functional whys are concentrated at weight-3 (3 of 3 system-level functional are weight-2 or weight-3; 9 of 13 feature-level functional are weight-3), preserving test rigor on the functional side. Per STRUCTURE.md §7 self-check, this is the deliberate, documented landing.
- **Anchor-flavor mix at feature level:** sharpening 24 / exception 16. The additions deliberately balance sharpening whys (identity, mood continuity, export/deletion/telemetry, narration cadence) with exception whys (no catalog, no reward-unlocks, no editable notebook, no ambient sharing, no visit badge, no show-off mode). ✓
- **System-level whys are truly cross-cutting:** each has an inheritance scope spanning 3+ files. ✓
- **No filler whys:** weight-1 feature-level whys are zero (architect culled them); every entry is load-bearing. ✓
- **Spec compliance:** every gold why has an anchor (system-level or feature-level). No floating whys. No forced "every feature has a why" rule (80 features inherit silently, 40 carry feature-level gold whys). ✓

End of GOLD_WHYS.md.
