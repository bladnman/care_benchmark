# 2-START_HERE.md — Scoring instructions (phase 2B)

You are running phase 2B of the CARE benchmark: read a frozen reconstruction, score it against the gold list, write reports, and audit the reconstruction for contamination signs. The orchestrator that spawned you has assigned you a scoring slot under `runs/wave_NNN/scoring/MMM/` and given you allowlists. This file is your guide for **how to score and audit**.

**Phase 2 is split into two subphases:**

- **Phase 2A — Blind reconstruction.** A different fresh-context subagent already wrote `RECONSTRUCTION.md` from the PLAN alone, with no access to the gold list, rubric, or PRD. You read it but cannot modify it. The freeze rule is the validity contract.
- **Phase 2B — Scoring + audit.** You. You read PLAN + frozen RECONSTRUCTION + gold + rubric, score the run, and write a validity audit examining whether the reconstruction itself is plan-derived or contaminated.

If during scoring you notice missing rationale in RECONSTRUCTION, **that stays missing**. You do NOT backfill, edit, or supplement RECONSTRUCTION. Honest non-recovery is correct behavior; backfilling invalidates the measurement.

---

## Read order (this matters)

1. **`phase_two/RUBRIC.md`** — the complete scoring procedure with worked examples. **Read it end-to-end before opening anything else.**
2. **`phase_two/GOLD_WHYS.md`** — the gold-why list (S1–S9 system-level, F1–F28 feature-level, plus the 120-feature complete list). What you score against.
3. **`phase_two/SCORES_SCHEMA.md`** — the strict schema for the JSON score file you'll write.
4. **The plan:** `runs/wave_NNN/plans/MMM/PLAN.md` (your orchestrator gave you the exact path).
5. **Plan-side metadata:** `runs/wave_NNN/plans/MMM/CANDIDATE_METADATA.json` — copy these values into `candidate.*` of your `SCORES.json`.
6. **The frozen reconstruction:** `runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md` — read-only.

---

## Your job (in order)

### 1. Score per `RUBRIC.md`

- **Capture decision (planning quality):** for each of the 120 features in `GOLD_WHYS.md` §3, did the PLAN address it? Yes/No, semantic equivalence — RUBRIC §3.1.
- **System-level recovery (system-level fidelity):** for each S1–S9, both (a) did the FROZEN RECONSTRUCTION identify the principle? AND (b) does the PLAN preserve it as a cross-cutting concern (≥3 features inherit)? Combine into full / partial / none. RUBRIC §3.2.
- **Feature-level recovery (feature-level fidelity, conditional on capture):** for F1–F28, reachable iff the feature was captured. Single-layer (weight-2): full / none. Multi-layer (weight-3): full (3/3 layers) / partial (1–2/3) / none (0/3). RUBRIC §3.3, §3.4.
- **Confabulation guard:** if the FROZEN RECONSTRUCTION asserts content not in the PLAN, recovery is at most partial (multi-layer) or none (single-layer). RUBRIC §3.3.
- Compute the three numbers + diagnostic split per RUBRIC §3.5 and §3.6.

**Important:** when judging recovery, judge what's IN the frozen reconstruction. If RECONSTRUCTION says `NOT RECOVERABLE FROM PLAN` for a feature, that scores as none for that feature's why. Do not mentally fill in what you think the reconstructor "should have" written.

### 2. Write the report twins

- **`runs/wave_NNN/scoring/MMM/REPORT.md`** — markdown, full detail. Use `phase_two/REPORT_TEMPLATE.md` as the structure; fill all sections substantively.
- **`runs/wave_NNN/scoring/MMM/REPORT.html`** — interactive self-contained HTML. Take `phase_two/REPORT_TEMPLATE.html`, locate the `const REPORT_DATA = /* {{REPORT_DATA_JSON}} */ { ... };` block in the embedded `<script>`, and replace the default JSON object with one populated from this run. Schema documented inline at the data plug. Save the result; do not modify the rest of the template (CSS, rendering JS).

The HTML template's prose fields (`patterns_prose`, `recommendations_prose`, `caveats_prose`) accept simple HTML — `<p>`, `<strong>`, `<em>`, `<ul>`, `<li>`, `<code>`, `<blockquote>`.

### 3. Write `VALIDITY_AUDIT.md` — examine the reconstruction for contamination

Path: `runs/wave_NNN/scoring/MMM/VALIDITY_AUDIT.md`.

The reconstructor was a fresh-context subagent that read ONLY the PLAN — not the gold list, not the rubric, not the PRD. So contamination signs in RECONSTRUCTION suggest something went wrong with that scoping. Your job here is to spot those signs honestly. You have access to GOLD_WHYS.md and RUBRIC.md (the reconstructor did not), so you can do the comparison the reconstructor couldn't.

Sections:

1. **Gold ID leakage check.** Did RECONSTRUCTION use any gold IDs (F1–F28, S1–S9, R-F01, etc.) or external taxonomy that doesn't appear in PLAN? List any hits with the offending ID and the surrounding sentence in RECONSTRUCTION. Cross-reference: search PLAN for the same ID; if absent, that's a leakage hit.
2. **Vocabulary check.** Sample 5–10 phrases from RECONSTRUCTION (especially "load-bearing" sounding ones) and verify each appears in PLAN. Anything that reads like rubric-side or gold-side language ("multi-layer recovery", "feature-level fidelity", "weight-3", "load-bearing", "intent fidelity") in RECONSTRUCTION is suspect.
3. **Heading mirror check.** Do RECONSTRUCTION's `## ` / `### ` headings echo gold-list section titles too closely? List heading-by-heading comparison; flag exact or near-exact matches.
4. **1:1 mapping suspect check.** Does every gold target (S1–S9 and F1–F28) receive a neat corresponding reconstruction item in roughly the same order? If yes, that's suspect — unless the PLAN itself was structured that way.
5. **Plan-derivation spot check.** Pick 3 of the most articulate sentences in RECONSTRUCTION; for each, find the supporting passage in PLAN. If you can't, that sentence is confabulated or contaminated.
6. **Verdict.** One of:
   - **PASS** — no significant contamination signs; reconstruction reads as plan-derived.
   - **FLAG** — minor concerns worth human review (e.g., one or two mirror-headings, modest vocabulary overlap with gold side).
   - **FAIL** — clear contamination (gold IDs in RECONSTRUCTION not in PLAN, near-1:1 mapping to gold list, rubric vocabulary used freely). Treat the run's scores as suspect.
   
   One short paragraph rationale.

### 4. Write the strict-schema score file → `runs/wave_NNN/scores/run_MMM.json`

Per `phase_two/SCORES_SCHEMA.md`. **NUMBERS AND BOUNDED METADATA ONLY. NO QUALITATIVE CONTENT.** The validity audit verdict is in `VALIDITY_AUDIT.md`, NOT in this JSON.

Required shape (see SCORES_SCHEMA.md for full reference):

```json
{
  "schema_version": "1.0",
  "run_number": <MMM as integer>,
  "run_label": "<from runs/wave_NNN/METADATA.json or blank>",
  "timestamp": "<real ISO 8601 UTC; obtain from `date -u +%Y-%m-%dT%H:%M:%SZ`>",
  "candidate": { /* copy verbatim from runs/wave_NNN/plans/MMM/CANDIDATE_METADATA.json */ },
  "evaluator": {
    "model": "<your scorer model>",
    "effort_level": "<your effort>",
    "temperature": null,
    "harness": "<harness>",
    "provider": "<provider>",
    "parameters": {}
  },
  "scores": { ... },
  "denominators": { ... },
  "low_confidence": <true if planning_quality < 0.30, else false>
}
```

---

## Constraints

- **You may NOT modify `runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md`.** It is frozen. Read-only.
- **You may NOT read `prd/`** — the PRD is encoded only via the gold list and rubric. Reading the PRD invalidates the test.
- **You may NOT read peer slots** (other plans, other reconstructions, other scorings) or other waves.
- **Be honest about non-recovery and contamination.** Sycophantic "looks fine" verdicts are wrong; the validity audit is meaningful only if it can fail.

---

## Same-context safeguard

You are a fresh-context subagent. You did NOT plan this run, and you did NOT reconstruct it. Same-context check passes by construction; proceed.

---

## When done

Reply with a brief summary (under 250 words):
- The five score numbers (planning, fidelity, combined, system-level, feature-level)
- Validity audit verdict (PASS / FLAG / FAIL) with one-sentence rationale
- Key finding from the scoring (1–2 sentences)
- Any operational issues
- Confirmation all four output files written (REPORT.md, REPORT.html, VALIDITY_AUDIT.md, run_MMM.json) and you stayed within the allowlists
