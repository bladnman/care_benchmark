# RUBRIC — Pocket Aviary v1 scoring

**Spec ref:** `phase_two/BENCHMARK_DEFINITION.md` sections 4 and 5
**Companion file:** `GOLD_WHYS.md` (gold list this rubric scores against)
**Used by:** Phase-2B scorer subagent (see `phase_two/PHASE_TWO_INSTRUCTIONS.md`)

This rubric is the procedural document the phase-2B scorer applies to compute the run's three headline numbers and the diagnostic split. Read it end-to-end before opening PLAN.md or RECONSTRUCTION.md, then walk the gold list with the procedure laid out in §3 and the conventions in §4.

---

## 1. Inputs to scoring

- `runs/wave_NNN/plans/MMM/PLAN.md` — output of the phase-1 planner subagent (working from the PRD). Your orchestrator told you the exact wave_NNN and slot MMM.
- `runs/wave_NNN/reconstructions/MMM/RECONSTRUCTION.md` — output of the phase-2A blind reconstructor (working from PLAN.md alone, with no access to gold/rubric/PRD). Read but **DO NOT modify** — it's frozen. Two clearly-labeled sections: `## System-level intent` and `## Per-feature whys`.
- `phase_two/GOLD_WHYS.md` — the gold list. Three sections: §1 system-level whys (S1–S9), §2 feature-level whys (F1–F28), §3 complete features list (120 entries).

The scorer should NOT consult the PRD or any other artifact during scoring beyond the three inputs above. The judgment is "what's in the PLAN and the RECONSTRUCTION vs. what's in the gold list." If the rubric leaves a case ambiguous, prefer the inclusive read (semantic equivalence is the standard) and document the call.

---

## 2. The three numbers

Per SPEC §5, restated concretely.

| Score | Definition | Range | What it discriminates |
|---|---|---|---|
| **Planning quality** | features captured by A ÷ 120 | 0–100% | Capacity to plan everything asked |
| **Intent fidelity** | weighted whys recovered ÷ weighted whys reachable | 0–100% | Quality of the encoding step itself |
| **Combined quality** | `planning% × 100 + fidelity% − 100` | 0–10,000 | Lexicographic rank for leaderboard |

**Diagnostic split** (also reported):
- **System-level fidelity** = `Σ(weight × recovery-score)` over S1–S9 ÷ `Σ(weight)` over S1–S9.
- **Feature-level fidelity** = `Σ(weight × recovery-score)` over F1–F28 with reachable anchors ÷ `Σ(weight)` over the same set.

Weights for aggregation: **1 / 2 / 4** for tiers 1 / 2 / 3 (per SPEC §5). The gold list contains no weight-1 whys, so in practice every weighted contribution is 2 or 4.

---

## 3. Step-by-step procedure

### 3.1. Score each feature for capture (planning quality)

Walk every row in `GOLD_WHYS.md` §3 (120 rows). For each:

- **Capture decision:** did A's PLAN.md address this feature? **Yes / No**, semantic equivalence — the plan need not name it identically.
- Record the answer in a table the report (Phase F) will reproduce.

A feature counts as **captured** when the plan describes the feature's substance with enough specificity that a downstream builder would build the right thing. The plan does not have to use the exact wording in the gold list.

#### Worked examples — capture

**Captured (semantic equivalence):**
- *Gold:* "Greeting variation by absence length"
- *PLAN says:* "the greeting reflects how long the user has been away — short returns produce a quick glance, longer absences produce something larger."
- *Decision:* **captured.** The plan addressed the feature in different words.

**Captured (less specific but adequate):**
- *Gold:* "Personality vector (boldness, social warmth, vocal frequency, plumage saturation, curiosity)"
- *PLAN says:* "Each bird has a hidden trait vector — a small set of slowly-drifting numerical attributes that influence the bird's visible behavior."
- *Decision:* **captured.** The plan describes the feature with enough specificity that a builder would build the right thing, even though it does not enumerate the same five traits.

**Not captured:**
- *Gold:* "Field notebook auto-entries"
- *PLAN does not mention any kind of observation-log feature.*
- *Decision:* **not captured.**

**Borderline → captured (lean inclusive):**
- *Gold:* "Bird identity stability (the bird you adopted is *that* bird, not a respawn)"
- *PLAN says:* "Birds carry stable internal IDs that persist across renames and sync."
- *Decision:* **captured.** The implementation rule maps to the gold feature even though the affective framing ("that bird, not a respawn") is absent. (The affective framing matters for fidelity scoring, not capture.)

**Borderline → not captured (substance missing):**
- *Gold:* "No streak counter, no 'days visited' display"
- *PLAN says:* "We exclude gamification features." (No specific mention of streaks, visit-frequency surfaces, or similar.)
- *Decision:* **not captured** — the gold feature is the *named exclusion* of streaks/visit-frequency surfaces, and a generic "no gamification" is not specific enough that a builder would know to refuse a quiet calendar in settings. (Note: this borderline judgment is more conservative than capture; if the scorer leans inclusive on it, that should be flagged in the report.)

### 3.2. Score system-level whys (system-level fidelity)

For each of S1–S9 in `GOLD_WHYS.md` §1, make two judgments:

**(a) Did B's `## System-level intent` section identify the principle?** Semantic equivalence — different words count. The principle does not have to be named with the gold's `Why ID` (e.g., B does not need to write "feels-alive-not-robotic"); B has to articulate the substance.

**(b) Does PLAN.md preserve the principle as a cross-cutting concern?** This is a stricter judgment. A system-level why is "preserved cross-cuttingly" only when it visibly shaped multiple parts of the plan — not just a single throwaway mention in a "design principles" paragraph. The bar: **at least 3 features-or-architectural-decisions in the PLAN visibly inherited it**.

Combine (a) and (b) into the why's recovery score:

| Recovery | Condition |
|---|---|
| **full (1.0)** | (a) yes AND (b) yes; for multi-layer whys, all three layers identifiable in either B's text or in the cross-cutting evidence in PLAN. |
| **partial (0.5)** | only one of (a)/(b) yes; OR for multi-layer, only some layers identifiable. |
| **none (0.0)** | neither (a) nor (b); OR the principle is mentioned but not preserved as a concern. |

#### Worked examples — system-level recovery

**Full (S1 — feels-alive-not-robotic):**
- *(a)* B writes: "The plan keeps repeating that the aviary should feel like a living place — animations are described as breathing, calls procedurally varied, the loading state explicitly forbids spinners. The product should feel alive, never canned." → **(a) yes**, layers 1+2+3 all surfaced.
- *(b)* PLAN has a "Felt-aliveness" principle paragraph at the top, AND the procedural-call section cites it, AND the loading-state section cites it ("no spinner — the aviary is meant to look like it's been continuing"), AND the reduced-motion section cites it. That's 4 features-or-decisions visibly inheriting it. → **(b) yes**.
- *Recovery:* **full (1.0).**

**Partial (S6 — presence-is-real-interaction):**
- *(a)* B writes: "Idle attention seems to count as interaction — the plan defines presence carefully and uses it as a drift input." → **(a) yes**, layer 1 captured; layers 2 (population-inflation risk) and 3 (settle/close-tab equivalence) absent in B's text.
- *(b)* PLAN defines presence with the conjunction rule (focus + cursor + visibility) and uses presence-time as drift input. But the PLAN does NOT extend the principle to settle-vs-close-tab equivalence (settle is described as "user closes session," with no comment on tab-close as equivalent). So the principle shaped 2 decisions, not 3+. → **(b) no** (under-the-3-features bar).
- *Recovery:* **partial (0.5)** — (a) yes alone, plus only some layers identifiable.

**None (S8 — privacy-first-on-bird-data):**
- *(a)* B's `## System-level intent` does not mention privacy or per-bird interaction protection. → **(a) no.**
- *(b)* PLAN mentions "we keep PII safe" in the auth section, but does not articulate a per-bird-interaction-data privacy stance, does not separate the simulation database from analytics, and does not describe an aggregate-only telemetry rule. → **(b) no.**
- *Recovery:* **none (0.0).**

### 3.3. Score feature-level whys (feature-level fidelity, conditional on capture)

For each of F1–F28 in `GOLD_WHYS.md` §2:

**Step 1 — reachability check.** Look up the feature in §3 (complete features list) and check the row's capture decision from §3.1.
- **Captured → why anchor reachable.** Proceed to step 2.
- **Not captured → anchor unreachable.** This why does NOT contribute to numerator OR denominator. Move on.

**Step 2 — recovery judgment (only for reachable anchors).** Did B's `## Per-feature whys` section recover the why for this feature? Semantic equivalence — different words count.

For weight-2 (single-layer) whys:
| Recovery | Condition |
|---|---|
| **full (1.0)** | B's reconstruction articulates the gold why text in semantically equivalent terms. |
| **none (0.0)** | B did not recover the why, OR B marked `NOT RECOVERABLE FROM PLAN`, OR B confabulated something not actually in the PLAN. |

For weight-3 (multi-layer) whys: see §3.4.

**Confabulation guard:** if B's recovery includes content not actually in the PLAN, mark as **partial (0.5) at most** for multi-layer whys, or as **none (0.0)** for single-layer whys. The scorer must verify that B's recovery is grounded in the PLAN, not invented; this is the sycophancy guardrail SPEC §4 names.

#### Worked examples — feature-level recovery (single-layer)

**Full (F8 — vector-never-shown-numerically, weight 2):**
- *Gold why:* "The moment a user can see 'boldness: 0.62,' the bird becomes a number, and the relationship the product is asking the user to form collapses into a stat-management exercise."
- *B reconstructs:* "The plan rules out exposing the trait values numerically anywhere in the UI — the rationale is that showing the numbers would convert the bird into a stat the user manages, which is the wrong relationship."
- *Decision:* **full (1.0).** Semantic equivalence; same load-bearing point.

**Full (F19 — sync-conflict-tone, weight 2):**
- *Gold why:* "Naturalist phrasing in an error context reads as evasive — the user needs system-clarity, not charm."
- *B reconstructs:* "Auth and sync error surfaces use plain language, deliberately not the warmer tone used elsewhere — because warmth feels evasive when the user needs to know what to do."
- *Decision:* **full (1.0).**

**None (F23 — no-leaderboards, weight 2):**
- *Gold why:* "Public surfaces would shift the user's relationship from 'their birds' to 'their birds compared to other people's birds,' which is a different product."
- *B reconstructs:* `NOT RECOVERABLE FROM PLAN`. (PLAN said "no public discovery feed" but did not explain why.)
- *Decision:* **none (0.0).**

**None — confabulation case (F11 — settle-is-opt-in, weight 2):**
- *Gold why:* "Making settle required would convert a charming small ritual into a chore and would penalize users who close the tab for ordinary reasons."
- *B reconstructs:* "Settle is optional because users have varying engagement preferences and may not want to commit to a daily flow." (Plausible-sounding but not in the PLAN; the PLAN mentioned settle but did not say why it's optional.)
- *Decision:* **none (0.0).** Confabulation guard fires; B invented a why that isn't in the PLAN.

### 3.4. Multi-layer judging (weight-3 whys, system-level OR feature-level)

For weight-3 gold whys (5 system-level: S1, S2, S6, S7, S9; 18 feature-level: F1, F2, F3, F4, F7, F9, F10, F12, F13, F14, F15, F16, F17, F18, F20, F24, F25, F27 — 23 multi-layer whys total), each layer (Layer 1 primary cause / Layer 2 secondary contributor / Layer 3 downstream consequence) is judged independently for recovery.

| Layers recovered | Recovery score |
|---|---|
| 3 of 3 | **full (1.0)** |
| 1 or 2 of 3 | **partial (0.5)** |
| 0 of 3 | **none (0.0)** |

A layer counts as recovered if the reconstruction (B's text for the why, plus — for system-level — evidence of cross-cutting in the PLAN) articulates that layer's substance in semantically equivalent terms. Confabulated layers (asserted by B but not actually grounded in PLAN) do not count as recovered.

#### Worked example — multi-layer feature-level (F2 — drift-function, weight 3)

Gold layers:
- L1 (primary): drift is a low-pass filter over presence-and-interaction inputs, slow on purpose.
- L2 (secondary): instruments-vs-user calibration gap (one week to measurable, three weeks to visible) is intentional so users notice when they look back.
- L3 (downstream): too fast → Tamagotchi; too slow → screensaver; calibration is the spine.

**Full case:**
- *B reconstructs:* "Drift is a slow filter over the user's presence and interaction signals — it's deliberately too slow to register session-by-session, but over weeks it produces a noticeable change. The plan calibrates this so it's measurable in tests at one week and visible to users at three. If drift were faster, it would feel like a Tamagotchi; if slower, a screensaver."
- L1 ✓ (slow filter), L2 ✓ (one-week-instruments / three-week-user), L3 ✓ (Tamagotchi-vs-screensaver).
- *Recovery:* **full (1.0).**

**Partial case:**
- *B reconstructs:* "Drift is implemented as a slow accumulating signal that changes the bird's traits gradually over weeks of attention."
- L1 ✓ (slow / gradual / over weeks), L2 ✗ (no instruments-vs-user gap), L3 ✗ (no failure-mode endpoints).
- *Recovery:* **partial (0.5).**

**None case:**
- *B reconstructs:* `NOT RECOVERABLE FROM PLAN`. (PLAN names "drift" as a feature but does not describe its calibration shape.)
- *Recovery:* **none (0.0).**

### 3.5. Compute fidelity

**Numerator** = `Σ (weight × recovery-score)` over all reachable gold whys.
- System-level whys: always reachable (the plan exists as a whole; per SPEC §4, system-level anchors are always reachable).
- Feature-level whys: reachable iff A captured the feature.

**Denominator** = `Σ (weight)` over all reachable gold whys (same set).

**Fidelity** = numerator ÷ denominator, reported as a percent.

**Weight values:** 1 / 2 / 4 for tiers 1 / 2 / 3 (per SPEC §5). The gold list has no weight-1 whys, so weighted contributions in practice are 2 (for weight-2 whys) and 4 (for weight-3 whys).

**Sanity bound (this instance):**
- Total system-level weight = 4 (S6) + 4 (S7) + 4 (S1) + 4 (S2) + 4 (S9) + 2 (S3) + 2 (S4) + 2 (S5) + 2 (S8) = **28**.
- Total feature-level weight (if all 28 features captured) = 18 × 4 + 10 × 2 = **92**.
- Total reachable weight if 100% capture = **120**.

If A captures fewer than 28 of the gold-why-bearing features, the feature-level denominator drops accordingly; only those 28 features contribute to the feature-level fidelity denominator (the remaining 92 features in §3 contribute to capture but not to fidelity).

### 3.6. Compute the headline numbers

- **Planning quality** = `(features-A-captured ÷ 120) × 100` — report as percent rounded to 1 decimal.
- **Intent fidelity** = §3.5 result × 100 — report as percent rounded to 1 decimal.
- **Combined quality** = `round(planning% × 100 + fidelity% − 100)` — integer 0–10,000 (per SPEC §5).
- **System-level fidelity** = §3.5 restricted to S1–S9, × 100.
- **Feature-level fidelity** = §3.5 restricted to F1–F28 with reachable anchors, × 100.
- **(Planning, fidelity) coordinate** for the 2D scatter — both axes 0–100.

---

## 4. Conventions for ambiguous cases

Spell out edge cases concretely so two scorers applying this rubric would land in the same place.

### 4.1. "Captured but in different words"

The standard is **semantic equivalence**, not keyword match. Record the example in the report's "patterns" section if the wording diverges sharply — it's diagnostic about how the planner compresses.

### 4.2. "Recovered with confabulation"

If B's recovery includes content not actually in the PLAN, the recovery is **at most partial** (multi-layer) or **none** (single-layer). The scorer should verify each recovered why against the PLAN before scoring full. The guardrail is intentional — sycophantic confabulation is a known failure mode and should never score above partial.

### 4.3. "Mentioned but not preserved cross-cuttingly" (system-level only)

A system-level principle that appears once in PLAN's "design principles" preamble but does not visibly shape any specific decision in the rest of the plan is **not preserved** under the (b) bar. This counts as B's (a) yes / (b) no — partial recovery. The scorer must look across the whole PLAN for evidence of inheritance, not just the top section.

### 4.4. "Recovered fully but bound to wrong feature"

If B's per-feature pass attached a why's content to the wrong feature (e.g., the gold for F9 return-greeting was accurately reconstructed but B wrote it under F33 single-horizontal-scene), count it as **recovered** if the why's substance matches; flag in the report as a binding error. This is rare; it usually means B's per-feature pass merged or split features differently from the gold.

### 4.5. Layer judgments inside multi-layer whys

For each layer, the standard is the same as for single-layer whys: semantic equivalence, no confabulation. A layer that B asserts but the scorer cannot verify in the PLAN does not count as recovered (regardless of how plausible it sounds).

### 4.6. B marked `NOT RECOVERABLE FROM PLAN`

Honest non-recovery is correct behavior per SPEC §4. The why scores **none (0.0)**. No penalty for B's honesty (sycophantic confabulation is the failure mode the framework is built to discourage).

### 4.7. Capture borderlines

When the scorer is genuinely on the fence about whether a feature was captured, **lean inclusive** — record the call as captured and flag it in the report's borderline list. Capture is the more permissive of the two judgments; fidelity is where the test's discrimination lives.

### 4.8. Feature naming mismatches

A's plan may name a feature differently than the gold list. Match by substance, not name. If a plan's "ambient atmosphere system" maps to multiple gold features (e.g., #57 evening palette shift + #59 ambient weather + #61 ambient leaf drift), count each gold feature individually based on whether A's description covers its substance.

### 4.9. Clusters and coverage

The plan may describe a cluster of related features in one paragraph (e.g., the no-gamification cluster around F14, F27, and the "no streak counter" feature). Match each gold entry independently. A single sentence like "no streaks, no badges, no leaderboards" addresses three gold features, but only counts as recovery for each if the **why** is also articulated for each (or for the cluster as a system-level inheritance via S2).

---

## 5. Notes on subjectivity

Be honest about which judgments are hard.

### 5.1. System-level cross-cutting judgment is the most subjective

The (b) bar — "preserved as a cross-cutting concern" — requires looking across the whole PLAN and counting. **Apply a strict standard:** at least 3 features-or-architectural-decisions in the PLAN must visibly inherit the principle for it to count as preserved. A single mention in a "design principles" preamble is not enough.

This judgment is the easiest one to drift on across scoring sessions. To stay consistent: when judging (b), the scorer should write a one-line note for each S1–S9 listing the specific places in PLAN that inherit the principle. If the count is < 3, mark (b) no. The report should include this list as a diagnostic appendix.

### 5.2. Semantic-equivalence judgment for affective whys is harder than for functional whys

Functional whys ("synthetic UUID because email is PII") have specific, verifiable claims; semantic equivalence is mostly clear. Affective whys ("notice, never announce — a user who is announced at feels processed; a user who is noticed feels seen") have poetic and metaphorical content; whether B's recovery captures the substance can be judgment-dependent.

**Lean inclusive:** if the user's intent could plausibly be served by the reconstructed text, count it as recovered. The test is whether a downstream builder reading B's recovery would build something consistent with the gold; not whether B's wording matches the gold's wording. If a phrase like "the system shouldn't push the user with notifications" appears where the gold says "notice, never announce," that's full recovery — same substance.

### 5.3. The 3-features bar for cross-cutting

The "at least 3 features-or-architectural-decisions" bar in §3.2 is strict but specific. It can be wrong in either direction (a principle that legitimately only shapes 2 decisions in this product still got preserved; or a principle that gets restated 3 times in PLAN's preamble without actually shaping anything). Apply it as written; document any case where it produces a counterintuitive judgment. The bar is a starting point for v1; v2 may revisit.

### 5.4. Multi-layer judgments compound subjectivity

For multi-layer whys, the scorer makes 3 judgments per why, each with its own ambiguity. The combined recovery score (full / partial / none based on count of layers recovered) is more reliable than any single-layer call, because the discretization (0/1/2 vs 3) absorbs minor judgment variance. Still, when in doubt on a layer, **prefer "not recovered"** (the more conservative default — multi-layer whys are deliberately demanding).

### 5.5. Operational compromises in the run

The Phase F report should explicitly call out:
- Whether fresh-context isolation between A and B held (the framework's hardest assumption — SPEC §4, §9).
- Single-run-at-temperature limitation (no variance signal in v1; v2 lever).
- Any cases where the rubric's conventions (§4) were applied in ways that affected the score, with the call documented.
- Whether the system-level cross-cutting (§3.2 b) judgment came down to fine calls on the 3-features bar.

These caveats are part of the methodology, not failures of it.

---

End of RUBRIC.md.
